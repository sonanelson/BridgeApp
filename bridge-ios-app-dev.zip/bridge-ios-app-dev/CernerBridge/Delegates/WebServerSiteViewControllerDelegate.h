//
//  WebServerSiteViewControllerDelegate.h
//  CernerBridge
//
//  Created by Gore,Divya on 12/7/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WebServerSiteViewControllerDelegate <NSObject>

/**
 * A method to load the login page based on the web server and web site set up.
 */
- (void)loadLoginPageBasedOnWebSettings;

@end
