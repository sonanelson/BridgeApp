//
//  WebActionResponderDelegate.h
//  CernerBridge
//
//  Created by Gore,Divya on 10/26/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol WebActionResponderDelegate <NSObject>

/**
 * Performs the required action on the webpage based on the javascript provided.
 */
- (void)performActionBasedOnJavascript:(NSString *)javascript;

/**
 * A method that specifies the action to be performed when the Menu Navigation Button is pressed.
 **/
- (void)performShowAppMenuAction;

@end
