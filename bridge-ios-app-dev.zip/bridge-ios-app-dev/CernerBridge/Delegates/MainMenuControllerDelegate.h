//
//  MainMenuControllerDelegate.h
//  CernerBridge
//
//  Created by Gore,Divya on 12/6/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@protocol MainMenuControllerDelegate <NSObject>

/**
 * A method called when an application is selected from all the menu options.
 **/
- (void)didSelectApplicationFromMenu;

@end
