//
//  NavigationBarDropDownMenuDelegate.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/5/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "MainNavigationBar.h"
#import <Foundation/Foundation.h>

/**
 * Protocol for Drop down menu actions corresponding to Navigation bar button clicks.
 */
@protocol NavigationBarDropDownMenuDelegate <NSObject>
/**
 * A method that specifies the action to be performed in the drop down view when the any navigation bar button is pressed.
 **/
- (void)performActionBasedOnNavigationBarButtonClick:(NavigationBarButtonTag)tag;
@end
