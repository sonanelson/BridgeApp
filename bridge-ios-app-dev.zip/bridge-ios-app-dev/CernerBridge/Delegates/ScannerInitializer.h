//
//  ScannerInitializer.h
//  CernerBridge
//
//  Created by Shoemake,Andrew on 1/31/19.
//  Copyright © 2019 Cerner Corporation. All rights reserved.
//

@protocol ScannerInitializer

/**
 * Implementer is responsible for setting up the mechanisms for barcode scanning
 */
- (void)setupScanning;

@end
