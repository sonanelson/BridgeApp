//
//  MainNavigationBar.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/5/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLElement.h"
#import "WebViewNavigationBarDelegate.h"
#import <UIKit/UIKit.h>

@protocol WebActionResponderDelegate;
@protocol NavigationBarDropDownMenuDelegate;

@interface MainNavigationBar : UINavigationBar <WebViewNavigationBarDelegate>
/**
 * Enum that specifies the different types of navigation bar button items.
 **/
typedef NS_ENUM(NSInteger, NavigationBarButtonTag) {
    kNavBarButton_Menu  = 0,
    kNavBarButton_Left  = 1,
    kNavBarButton_Right = 2
};
/**
 * The delegate associated with the web action responder protocol.
 */
@property (nonatomic, weak) id<WebActionResponderDelegate> actionDelegate;
/**
 * Delegate object for NavigationBarDropDownMenuDelegate.
 **/
@property (nonatomic, weak) id<NavigationBarDropDownMenuDelegate> dropDownMenuDelegate;

/**
 *  Parses all the required drop down menu elements from the current HTML with the title.
 **/
- (void)parseItemsWithTitle:(NSString *)title fromHTML:(NSString *)HTML;
@end
