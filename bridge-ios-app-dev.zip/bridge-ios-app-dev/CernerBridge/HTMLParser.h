//
//  HTMLParser.h
//  CernerBridge
//
//  Created by Shoemake,Andrew on 9/13/18.
//  Copyright © 2018 DWx CareAware Connect. All rights reserved.
//

#import "HTMLElement.h"
#import <Foundation/Foundation.h>

@interface HTMLParser : NSObject
/**
 * Retrieve HTML elements using the provided xPath Query
 *
 * Supports simple xPath queries such as:
 * //div - Find all div elements
 * //div|//a - Find all div and a elements
 * //div//a - Find all a elements that are descendents of div elements
 * 
 * @param html - The HTML to search
 * @param xPathQualifier - The xPath query to use
 * @return An array of HTMLElements that match the xPath query
 */
- (NSArray<HTMLElement *> *)elementsFromHTML:(NSString *)html withXPath:(NSString *)xPathQualifier;
@end
