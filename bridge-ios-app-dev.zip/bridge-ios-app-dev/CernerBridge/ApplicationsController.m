//
//  MainMenuController.m
//  Cerner Bridge
//
//  Created by Bechtold,Brian on 10/26/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import "ApplicationsController.h"
#import "BridgeCommonConstants.h"
#import "MainViewController.h"

// Helpers
#import "NSString+Additions.h"
#import "NSUserDefaults+BridgeAdditions.h"

// General Keys
static NSString *const kTitleKey = @"title";

// Title Keys
static NSString *const kTranfusionTitleKey = @"transfusionTitle";
static NSString *const kSpecimenTitleKey   = @"specimenTitle";
static NSString *const kMilkTitleKey       = @"milkTitle";
static NSString *const kDonorMilkTitleKey  = @"donorTitle";
static NSString *const kBabyMatchTitleKey  = @"babyMatchTitle";
static NSString *const kMedAdminTitleKey   = @"medAdminTitle";

// Default Titles
static NSString *const kTranfusionDefaultTitle = @"Transfusion Administration";
static NSString *const kSpecimenDefaultTitle   = @"Specimen Collection";
static NSString *const kMilkDefaultTitle       = @"Breast Milk Management";
static NSString *const kDonorMilkDefaultTitle  = @"Donor Milk";
static NSString *const kBabyMatchDefaultTitle  = @"Baby Match";
static NSString *const kMedAdminDefaultTitle   = @"Medication Administration";

@interface ApplicationsController ()
/**
 * Array containing all the items to be displayed in the menu.
 */
@property (nonatomic, retain) NSMutableArray<NSString *> *applicationsList;
/**
 * Dictionary containing appropriate indexes of all the available applications.
 */
@property (nonatomic, retain) NSMutableDictionary<NSString *, NSNumber *> *availableApplicationIndexes;
@end

@implementation ApplicationsController

#pragma mark - Set up Methods

+ (instancetype)createMainMenuViewController {
    UIStoryboard *mainStoryBoard = [UIStoryboard storyboardWithName:@"Main" bundle:nil];
    return [mainStoryBoard instantiateViewControllerWithIdentifier:@"MainMenuController"];
}

- (NSArray *)defaultTitleKeysArray {
    return @[kTranfusionTitleKey, kSpecimenTitleKey, kMilkTitleKey, kBabyMatchTitleKey, kDonorMilkTitleKey, kMedAdminTitleKey];
}

- (NSDictionary *)getDefaultTitleKeysFromApplicationKeys {
    return [NSDictionary dictionaryWithObjects:[self defaultTitleKeysArray] forKeys:[NSUserDefaults arrayForBridgeApplicationKeys]];
}

- (NSDictionary *)getDefaultTitleFromTitleKeys {
    NSString *transfusionTitle = NSLocalizedStringWithDefaultValue(@"MENU.DEFAULT.TITLE.TRANSFUSION",
                                                                   kTable_Localization,
                                                                   [NSBundle mainBundle],
                                                                   @"Transfusion Administration",
                                                                   @"Transfusion default title");

    NSString *specimenTitle = NSLocalizedStringWithDefaultValue(@"MENU.DEFAULT.TITLE.SPECIMEN",
                                                                kTable_Localization,
                                                                [NSBundle mainBundle],
                                                                @"Specimen Collection",
                                                                @"Specimen default title");

    NSString *breastMilkTitle = NSLocalizedStringWithDefaultValue(@"MENU.DEFAULT.TITLE.MILK",
                                                                  kTable_Localization,
                                                                  [NSBundle mainBundle],
                                                                  @"Breast Milk Management",
                                                                  @"Milk default title");

    NSString *babyMatchTitle = NSLocalizedStringWithDefaultValue(@"MENU.DEFAULT.TITLE.BABY.MATCH",
                                                                 kTable_Localization,
                                                                 [NSBundle mainBundle],
                                                                 @"Baby Match",
                                                                 @"Baby Match default title");

    NSString *donorMilkTitle = NSLocalizedStringWithDefaultValue(@"MENU.DEFAULT.TITLE.DONOR.MILK",
                                                                 kTable_Localization,
                                                                 [NSBundle mainBundle],
                                                                 @"Donor Milk",
                                                                 @"Donor Milk default title");

    NSString *medAdminTitle = NSLocalizedStringWithDefaultValue(@"MENU.DEFAULT.TITLE.MED.ADMIN",
                                                                kTable_Localization,
                                                                [NSBundle mainBundle],
                                                                @"Medication Administration",
                                                                @"Med Admin default title");

    return [NSDictionary dictionaryWithObjects:@[transfusionTitle, specimenTitle, breastMilkTitle, babyMatchTitle, donorMilkTitle, medAdminTitle]
                                       forKeys:[self defaultTitleKeysArray]];
}

#pragma mark - Lifecycle Methods

- (void)viewDidLoad {
    [super viewDidLoad];

    self.applicationsList            = [NSMutableArray arrayWithCapacity:6];
    self.availableApplicationIndexes = [NSMutableDictionary dictionaryWithCapacity:6];

    NSInteger appIndex = 0;
    // Get titles of all the Application menu options.
    for (NSString *applicationKey in [NSUserDefaults arrayForBridgeApplicationKeys]) {
        // Check if user defaults have been set for the given application key.
        // Set title only if the default is enabled, else move to the next.
        if (![NSUserDefaults checkIfDefaultIsEnabledForKey:applicationKey]) {
            appIndex++;
            continue;
        }

        // If default is set for the given key, get title and add it to the menu option list.
        NSString *titleKey = self.getDefaultTitleKeysFromApplicationKeys[applicationKey];
        NSString *title    = self.getDefaultTitleFromTitleKeys[titleKey];

        [self.applicationsList addObject:title];
        self.availableApplicationIndexes[title] = @(appIndex);

        appIndex++;
    }
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [self.applicationsList count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    static NSString *cellIdentifier = @"ApplicationsCellIdentifier";
    UITableViewCell *cell           = [tableView dequeueReusableCellWithIdentifier:cellIdentifier forIndexPath:indexPath];

    if (cell == NULL) {
        cell               = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:cellIdentifier];
        cell.accessoryType = UITableViewCellAccessoryDisclosureIndicator;
    }

    // Set Application title name.
    cell.textLabel.text = [self.applicationsList objectAtIndex:indexPath.row];
    return cell;
}

#pragma mark - Table view delegate

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath {
    // Set the selected application and call delegate to load the correct login page for the given application.
    NSString *key = self.applicationsList[indexPath.row];

    NSInteger selectedApplicationIndex = [self.availableApplicationIndexes[key] integerValue];

    [NSUserDefaults setSelectedApplicationIndex:selectedApplicationIndex];
    [self.delegate didSelectApplicationFromMenu];
}

@end
