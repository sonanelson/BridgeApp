//
//  MainNavigationViewController.h
//  CernerBridge
//
//  Created by Gore,Divya on 10/10/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainNavigationViewController : UINavigationController

@end
