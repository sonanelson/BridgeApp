//
//  AlertViewUtils.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/13/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "AlertViewUtils.h"
#import "BridgeCommonConstants.h"

// Helpers
#import "MainViewUtils.h"
#import "NSMutableDictionary+AlertViewHelper.h"
#import "NSString+Additions.h"

@implementation AlertViewUtils

+ (UIAlertController *)alertForWebSettingAlertType:(WebSettingAlertType)type withErrorDescription:(NSString *)description {
    NSString *title       = @"";
    NSString *message     = @"";
    NSString *help        = NSLocalizedStringWithDefaultValue(@"ALERT.MSG.HELP",
                                                       kTable_Localization,
                                                       [NSBundle mainBundle],
                                                       @"Please check settings or contact system administrator for assistance.",
                                                       @"Alert message for help.");
    BOOL shouldAppendHelp = NO;

    switch (type) {
    case kWebSettingAlertType_EmptyField:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.TITLE.WEB.FIELDS.EMPTY",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Entry Required",
                                                  @"Alert title for empty fields.");

        message = NSLocalizedStringWithDefaultValue(@"ALERT.MSG.WEB.FIELDS.EMPTY",
                                                    kTable_Localization,
                                                    [NSBundle mainBundle],
                                                    @"Web Server and Site Name entries are required to run Cerner Bridge Solutions. "
                                                    @"Please contact system administrator if you do not have these values.",
                                                    @"Alert message for empty fields.");
        break;

    case kWebSettingAlertType_InvalidURL:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.TITLE.INVALID.URL",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Invalid Server or Site Name",
                                                  @"Alert title for invalid URL.");

        message = NSLocalizedStringWithDefaultValue(@"ALERT.MSG.INVALID.URL",
                                                    kTable_Localization,
                                                    [NSBundle mainBundle],
                                                    @"The entry supplied was not valid for Server or Site Name. "
                                                    @"Please check settings or contact system administrator for assistance.",
                                                    @"Alert message for invalid URL.");

        break;

    case kWebSettingAlertType_InvalidResponse:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.TITLE.INVALID.RESPONSE",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Error Connecting to Bridge Web Site",
                                                  @"Alert title for invalid response.");

        message = NSLocalizedStringWithDefaultValue(@"ALERT.MSG.INVALID.RESPONSE.CODE",
                                                    kTable_Localization,
                                                    [NSBundle mainBundle],
                                                    @"Unable to access the Bridge Web Site with the following status: ",
                                                    @"Alert message for invalid response code.");

        shouldAppendHelp = YES;

        break;

    case kWebSettingAlertType_Error:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.TITLE.ERROR",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Error Connecting to Bridge Server",
                                                  @"Alert title for web settings error.");

        message = NSLocalizedStringWithDefaultValue(@"ALERT.MSG.ERROR",
                                                    kTable_Localization,
                                                    [NSBundle mainBundle],
                                                    @"Bridge Web Server connection failed:",
                                                    @"Alert message for web settings error.");

        shouldAppendHelp = YES;
        break;
    }

    NSString *alertMessage = shouldAppendHelp ? [NSString stringWithFormat:@"%@\n \"%@\" \n\n %@", message, description, help] : message;
    return [AlertViewUtils alertContainingOKButtonWithTitle:title andMessage:alertMessage];
}

+ (UIAlertController *)alertWithErrorType:(ErrorAlertType)type andMessage:(NSString *)errorMessage {
    NSString *title = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.TITLE",
                                                        kTable_Localization,
                                                        [NSBundle mainBundle],
                                                        @"Web Error Received",
                                                        @"Error title for alert.");

    NSString *message = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.MESSAGE.BODY",
                                                          kTable_Localization,
                                                          [NSBundle mainBundle],
                                                          @"Click OK to Retry."
                                                          @"\nClick Logout to return to Login Page."
                                                          @"\nIf the problem persists, please contact the system administrator.",
                                                          @"Body for the error message.");

    switch (type) {
    case kErrorAlertType_Server:
        message = NSLocalizedStringWithDefaultValue(@"ALERT.SERVER.ERROR.MESSAGE.BODY",
                                                    kTable_Localization,
                                                    [NSBundle mainBundle],
                                                    @"Verify Web Server Name and Web Site Name in Settings->Cerner Bridge and contact system administrator.",
                                                    @"Body for the server error message.");

        message = [NSString stringWithFormat:@"%@: %@. \n %@", title, errorMessage, message];
        break;

    case kErrorAlertType_General:
        message = [NSString stringWithFormat:@"%@: %@. \n %@", title, errorMessage, message];
        break;

    case kErrorAlertType_PageTimeoutError:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.PAGE.TIMEOUT.TITLE",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Page Load Timeout",
                                                  @"Alert: Title for page timeout.");

        if (errorMessage != NULL) {
            message = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.MESSAGE.NO.LOGOUT.BODY",
                                                        kTable_Localization,
                                                        [NSBundle mainBundle],
                                                        @"Click OK to Retry."
                                                        @"\nIf the problem persists, please contact the system administrator.",
                                                        @"Body for the error message without logout.");
        }
        break;

    case kErrorAlertType_InvalidBarcode:
        // TODO: Update these title and messages when the reqs are updated.
        title = NSLocalizedStringWithDefaultValue(@"ALERT.INVALID.SCAN.TITLE",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Invalid Barcode Scan",
                                                  @"Alert: Title for invalid barcode scan.");
        ;
        message = NSLocalizedStringWithDefaultValue(@"ALERT.INVALID.SCAN.MESSAGE.BODY",
                                                    kTable_Localization,
                                                    [NSBundle mainBundle],
                                                    @"Please try again or try manually entering the barcode value.",
                                                    @"Body for the invalid scan message.");
        break;
    }
    return [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
}

+ (UIAlertController *)alertForBarcodeScannerConnectionError:(BarcodeScannerConnectionAlertType)type {
    NSString *title;
    NSString *messageTemplate = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.MESSAGE.SCANNER.CONNECTION.MESSAGE",
                                                                  kTable_Localization,
                                                                  [NSBundle mainBundle],
                                                                  @"Failure to initialize barcode scanner.\nTry again or contact your help desk for assistance. (%ld)",
                                                                  @"Message body for when the barcode scanner cannot be initialized");

    NSString *message = [NSString localizedStringWithFormat:messageTemplate, (long)type];

    switch (type) {
    case kScannerConnection_LicenseInvalid:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.TITLE.SCANNER.CONNECTION.LICENSE_INVALID",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Failure to Initialize Barcode Scanner",
                                                  @"Title for alert when license is invalid");
        break;
    case kScannerConnection_NetworkUnavailable:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.TITLE.SCANNER.CONNECTION.NETWORK_UNAVAILABLE",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Network Unavailable",
                                                  @"Title for alert when network is unavailable(wifi)");
        break;
    case kScannerConnection_LicenseServerUnavailable:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.TITLE.SCANNER.CONNECTION.SERVER_UNAVAILABLE",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"License Server Unavailable",
                                                  @"Title for alert when license server is unavailable(server might be down)");
        break;
    case kScannerConnection_LicenseExpired:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.TITLE.SCANNER.CONNECTION.LICENSE_EXPIRED",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"Scanner License Expired",
                                                  @"Title for alert when scanner license has expired");
        break;
    case kScannerConnection_GeneralError:
        title = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.TITLE.SCANNER.CONNECTION.GENERAL_ERROR",
                                                  kTable_Localization,
                                                  [NSBundle mainBundle],
                                                  @"General Error",
                                                  @"Title for alert when general error happens");
        break;
    }
    return [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
}

+ (UIAlertController *)alertWithTitle:(NSString *)title andMessage:(NSString *)message {
    return [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];
}

+ (UIAlertController *)alertFromHTMLElements:(NSArray<HTMLElement *> *)elements {
    // The alert can be a confirm alert or a normal alert.
    // Confirm alert will be in the format: "http://action/alert?<message><clickAction>;<alert>" or "http://action/confirm?<message><clickAction>;<alert>"
    // Normal alerts will be in the format: javascript:alert(\"Title<br>btn:buttonTitle<br>message\");

    // If alert is of type confirm, we don't need to do anything.
    // This alert will be presented by one of the webview delegates.
    if ([AlertViewUtils isConfirmAlert:elements.firstObject.text]) {
        return NULL;
    }

    NSDictionary *detailsInfo = [NSMutableDictionary extractAlertDetailsfromHTMLElements:elements];
    NSArray *details          = [detailsInfo objectForKey:kKey_Alert_Details];
    return [UIAlertController alertControllerWithTitle:details.firstObject message:details.lastObject preferredStyle:UIAlertControllerStyleAlert];
}

+ (UIAlertController *)alertContainingOKButtonWithTitle:(NSString *)title andMessage:(NSString *)message {
    // the alert will have a title, message and one button with the title 'OK'.
    NSString *localizedOK = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.BUTTON.OK",
                                                              kTable_Localization,
                                                              [NSBundle mainBundle],
                                                              @"OK",
                                                              @"Alert: OK Button title.");

    UIAlertController *controller = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:UIAlertControllerStyleAlert];

    UIAlertAction *action = [UIAlertAction actionWithTitle:localizedOK style:UIAlertActionStyleCancel handler:nil];

    [controller addAction:action];
    return controller;
}

+ (UIAlertController *)alertWithTitle:(NSString *)title details:(NSDictionary *)details {
    NSString *alertMsg = ([details objectForKey:kKey_Alert_Message]) ? details[kKey_Alert_Message] : @"";
    return [AlertViewUtils alertWithTitle:title andMessage:alertMsg];
}

+ (NSArray *)alertButtonTitlesFromDetails:(NSDictionary *)details {
    NSMutableArray *actionTitles = [NSMutableArray arrayWithCapacity:2];
    if ([details objectForKey:kKey_Alert_ButtonOK]) {
        [actionTitles addObject:details[kKey_Alert_ButtonOK]]; // OK Button text
    }
    if ([details objectForKey:kKey_Alert_ButtonCancel]) {
        [actionTitles addObject:details[kKey_Alert_ButtonCancel]]; // Cancel Button text
    }
    return actionTitles;
}

+ (NSArray *)alertButtonTitlesFromElements:(NSArray<HTMLElement *> *)elements {
    // The alert will always be in the form:: javascript:alert(\"Title<br>btn:buttonTitle<br>message\");
    NSDictionary *detailsInfo = [NSMutableDictionary extractAlertDetailsfromHTMLElements:elements];
    return [detailsInfo objectForKey:kKey_Alert_ButtonTitle];
}

+ (NSArray *)alertButtonTitlesWithLogout:(BOOL)shouldIncludeLogout {
    NSString *localizedOK = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.BUTTON.OK",
                                                              kTable_Localization,
                                                              [NSBundle mainBundle],
                                                              @"OK",
                                                              @"Alert: OK Button title.");

    NSString *localizedLogout = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.BUTTON.LOGOUT",
                                                                  kTable_Localization,
                                                                  [NSBundle mainBundle],
                                                                  @"Logout",
                                                                  @"Alert: Logout Button title.");

    return shouldIncludeLogout ? @[localizedOK, localizedLogout] : @[localizedOK];
}

+ (NSArray *)defaultAlertButtonTitlesWithCancel:(BOOL)shouldAddCancel {
    NSString *localizedOK = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.BUTTON.OK",
                                                              kTable_Localization,
                                                              [NSBundle mainBundle],
                                                              @"OK",
                                                              @"Alert: OK Button title.");
    if (!shouldAddCancel) {
        return @[localizedOK];
    }

    NSString *localizedCancel = NSLocalizedStringWithDefaultValue(@"ALERT.ERROR.BUTTON.CANCEL",
                                                                  kTable_Localization,
                                                                  [NSBundle mainBundle],
                                                                  @"Cancel",
                                                                  @"Alert: Cancel Button title.");
    return @[localizedOK, localizedCancel];
}

+ (BOOL)isConfirmAlert:(NSString *)alert {
    if ([alert containsString:kURLPath_Confirm] || [alert containsString:kURLPath_Alert]) {
        return YES;
    }
    return NO;
}

@end
