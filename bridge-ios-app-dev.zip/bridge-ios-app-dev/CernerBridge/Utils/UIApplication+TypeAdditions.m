//
//  UIApplication+TypeAdditions.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/19/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIApplication+TypeAdditions.h"

@implementation UIApplication (TypeAdditions)

+ (InactivityApplication *)inactivityApplication {
    return (InactivityApplication *)[UIApplication sharedApplication];
}

@end
