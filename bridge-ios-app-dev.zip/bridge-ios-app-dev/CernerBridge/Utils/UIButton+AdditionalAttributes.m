//
//  UIButton+AdditionalAttributes.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIButton+AdditionalAttributes.h"
#import "UIColor+BridgeColors.h"

@implementation UIButton (AdditionalAttributes)

- (UIColor *)titleColorForMainBottomBar {
    // Disabled items should always be greyed out.
    return ![self isEnabled] ? [UIColor inactiveTextColor] : [UIColor defaultTextColor];
}

- (UIColor *)titleColorForSecondaryBottomBar:(BOOL)isCancelButton {
    // Disabled items should always be greyed out.
    if (![self isEnabled]) {
        return [UIColor inactiveTextColor];
    }

    // The cancel/ exit button should always be grey.
    return isCancelButton ? [UIColor inactiveTextColor] : [UIColor defaultTextColor];
}

- (void)centerContentWithImageOnTopOfSize:(CGSize)imageSize title:(NSString *)title andFont:(UIFont *)font {
    self.titleEdgeInsets = UIEdgeInsetsMake((imageSize.height), -imageSize.width, 0, 0);
    CGSize titleSize     = [title sizeWithAttributes:@{NSFontAttributeName: font}];
    self.imageEdgeInsets = UIEdgeInsetsMake(-(titleSize.height), 0.0f, 0, -titleSize.width);
}

@end
