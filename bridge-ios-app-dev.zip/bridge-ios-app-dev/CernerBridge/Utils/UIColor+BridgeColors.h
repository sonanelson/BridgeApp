//
//  UIColor+BridgeColors.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (BridgeColors)
/**
 * Returns the bottom bar color.
 */
+ (UIColor *)bottomBarColor;
/**
 * Returns the default text color.
 */
+ (UIColor *)defaultTextColor;
/**
 * Returns the inactive text color.
 */
+ (UIColor *)inactiveTextColor;
@end
