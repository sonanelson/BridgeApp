//
//  UIFont+BridgeFonts.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIFont+BridgeFonts.h"

@implementation UIFont (BridgeFonts)

+ (NSString *)defaultBridgeFontName {
    return @"OpenSans";
}

+ (UIFont *)bottomBarFont {
    return [UIFont fontWithName:[UIFont defaultBridgeFontName] size:14.0f];
}

+ (UIFont *)defaultTitleFont {
    return [UIFont fontWithName:[UIFont defaultBridgeFontName] size:16.0f];
}

@end
