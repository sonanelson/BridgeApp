//
//  SoundUtils.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/21/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SoundUtils : NSObject
/**
 * Plays the default alert warning sound.
 */
+ (void)playDefaultAlertSound;
@end
