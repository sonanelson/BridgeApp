//
//  AlertViewUtils.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/13/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "HTMLElement.h"

@interface AlertViewUtils : NSObject

/**
 * Enum for defining types of alerts showing errors.
 **/
typedef NS_ENUM(NSInteger, ErrorAlertType) {
    kErrorAlertType_Server           = 0, // Server Error
    kErrorAlertType_PageTimeoutError = 1, // Page Timeout Error
    kErrorAlertType_General          = 2, // Any Other Error
    kErrorAlertType_InvalidBarcode   = 3  // Barcode is invalid
};
/**
 * Enum for defining types of alerts showing errors on the web server settings page.
 **/
typedef NS_ENUM(NSInteger, WebSettingAlertType) {
    kWebSettingAlertType_EmptyField      = 0, // The website server and site fields are empty.
    kWebSettingAlertType_InvalidURL      = 1, // The URL is invalid
    kWebSettingAlertType_InvalidResponse = 2, // The response from the URL is invalid
    kWebSettingAlertType_Error           = 3  // Any other error
};

typedef NS_ENUM(NSInteger, BarcodeScannerConnectionAlertType) {
    kScannerConnection_LicenseInvalid           = 100,
    kScannerConnection_NetworkUnavailable       = 101,
    kScannerConnection_LicenseServerUnavailable = 102,
    kScannerConnection_LicenseExpired           = 103,
    kScannerConnection_GeneralError             = 104
};

/**
 * Initializes alert for the given error type and with the given error message.
 *
 * @return UIAlertController New alert controller with correct title and message for the given error type.
 */
+ (UIAlertController *)alertWithErrorType:(ErrorAlertType)type andMessage:(NSString *)errorMessage;

/**
 * Initializes alert for the given Web settings error type and with the given error description.
 *
 * @return UIAlertController New alert controller with correct title, message for the given error type and OK button.
 */
+ (UIAlertController *)alertForWebSettingAlertType:(WebSettingAlertType)type withErrorDescription:(NSString *)description;

/**
 * Initialiezes alert for the given Barcode Scanner Connection Error Type
 *
 * @return UIAlertController New alert controller with correct title, message for the given scanner connection error and OK button
 *
 */
+ (UIAlertController *)alertForBarcodeScannerConnectionError:(BarcodeScannerConnectionAlertType)type;

/**
 * Initializes alert with given title and message.
 *
 * @return UIAlertController New alert controller with correct title and message.
 */
+ (UIAlertController *)alertWithTitle:(NSString *)title andMessage:(NSString *)message;

/**
 * Initializes alert with title and message extracted from the given HTMLElement array.
 *
 * @return UIAlertController New alert controller with correct title and message.
 */
+ (UIAlertController *)alertFromHTMLElements:(NSArray<HTMLElement *> *)elements;

/**
 * Initializes alert with title and any other information provided.
 *
 * @return UIAlertController New alert controller with correct title and other details provided.
 */
+ (UIAlertController *)alertWithTitle:(NSString *)title details:(NSDictionary *)details;

/**
 * Get alert action titles extracted from the given HTMLElement array.
 *
 * @return NSArray An array containing titles for alert actions.
 */
+ (NSArray *)alertButtonTitlesFromElements:(NSArray<HTMLElement *> *)elements;

/**
 * Get alert action titles and include logout action based on the given bool.
 *
 * @return NSArray An array containing titles for alert actions.
 */
+ (NSArray *)alertButtonTitlesWithLogout:(BOOL)shouldIncludeLogout;

/**
 * Get button titles from the details provided.
 *
 * @return NSArray An array containing titles for alert actions.
 */
+ (NSArray *)alertButtonTitlesFromDetails:(NSDictionary *)details;
/**
 * Get the default alert button titles if none are specified.
 *
 * @return NSArray of default alert button titles.
 */
+ (NSArray *)defaultAlertButtonTitlesWithCancel:(BOOL)shouldAddCancel;
@end
