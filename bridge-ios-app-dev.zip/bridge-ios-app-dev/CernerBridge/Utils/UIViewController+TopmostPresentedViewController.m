//
//  UIViewController+TopmostPresentedViewController.m
//  CernerBridge
//
//  Created by Gore,Divya on 12/3/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIViewController+TopmostPresentedViewController.h"

@implementation UIViewController (TopmostPresentedViewController)

+ (UIViewController *)topmostViewController {
    UIViewController *rootViewController = [[[UIApplication sharedApplication] delegate].window rootViewController];
    return [UIViewController topmostViewControllerForRoot:rootViewController];
}

+ (UIViewController *)topmostViewControllerForRoot:(UIViewController *)rootViewController {
    UIViewController *presentedViewController = rootViewController.presentedViewController;
    if (presentedViewController == nil) {
        return rootViewController;
    } else if ([presentedViewController isKindOfClass:[UINavigationController class]]) {
        // If the top view controller is a Navigation Controller
        UINavigationController *navigationController = (UINavigationController *)presentedViewController;
        return [UIViewController topmostViewControllerForRoot:navigationController.viewControllers.lastObject];
    } else if ([presentedViewController isKindOfClass:[UITabBarController class]]) {
        // If the top view controller is a Tabbar Controller
        UITabBarController *tabbarController = (UITabBarController *)presentedViewController;
        return [UIViewController topmostViewControllerForRoot:tabbarController.selectedViewController];
    } else {
        // If the top view controller is of any other class
        return [UIViewController topmostViewControllerForRoot:presentedViewController];
    }
}

@end
