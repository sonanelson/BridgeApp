//
//  UIApplication+TypeAdditions.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/19/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "InactivityApplication.h"
#import <UIKit/UIKit.h>

@interface UIApplication (TypeAdditions)

+ (InactivityApplication *)inactivityApplication;

@end
