//
//  HTMLElement+TypeHelper.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "HTMLElement.h"

@interface HTMLElement (TypeHelper)

/**
 * A method to detemine if the HTMLElement contains text to enable the patients button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypePatient;
/**
 * A method to detemine if the HTMLElement contains text to enable the cancel button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeCancel;
/**
 * A method to detemine if the HTMLElement contains text to enable the continue button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeContinue;
/**
 * A method to detemine if the HTMLElement contains text to enable the home button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeHome;
/**
 * A method to detemine if the HTMLElement contains text to enable the logout button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeLogout;
/**
 * A method to detemine if the HTMLElement contains text to enable the back button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeBack;
/**
 * A method to detemine if the HTMLElement contains text to enable the filter button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeFilter;
/**
 * A method to detemine if the HTMLElement contains text to enable the scan button.
 *
 * @return true if it contains the text, else false.
 */
- (BOOL)isOfTypeScan;

@end
