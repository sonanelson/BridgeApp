//
//  MainViewUtils.m
//  CernerBridge
//
//  Created by Gore,Divya on 10/16/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "MainViewUtils.h"
#import "NSString+Additions.h"

static NSString *const kWebErrorString  = @"Web Error Received";
static NSString *const kPageLoadTimeout = @"Page Load Timeout";
static NSString *const kWebKitError     = @"WebKitError";
static NSString *const kServerError     = @"Server Error";
static NSString *const kHTTPStatus      = @"HTTP Status";
static NSString *const kHTTPError       = @"HTTP Error";
static NSString *const kFormTag         = @"<FORM";

@implementation MainViewUtils

+ (NSString *)getPageNameFromURL:(NSString *)URLString {
    NSURL *url                         = [NSURL URLWithString:URLString];
    NSArray<NSString *> *urlComponents = [url pathComponents];
    NSString *pageName                 = @"";

    for (NSInteger i = 0; i < urlComponents.count; i++) {
        NSInteger aspxIndex = [urlComponents[i] getIndexOfText:@".aspx"];
        if (aspxIndex <= 0) {
            continue;
        }
        pageName = [urlComponents[i] substringToIndex:aspxIndex];
        break;
    }
    return pageName;
}

+ (NSArray<NSString *> *)getAllLoginPages {
    NSArray<NSString *> *loginPages = @[@"Login.aspx", @"SystemMessage.aspx", @"welcome.do", @"hhscanLoginID.do", @"logout.do"];
    return loginPages;
}

+ (NSArray<NSString *> *)getAllPasswordPages {
    NSArray<NSString *> *passwordPages = @[@"ChangePassword.aspx", @"ExpiredPassword.aspx"];
    return passwordPages;
}

+ (BOOL)isStartPage:(NSString *)page {
    for (NSString *loginPage in [MainViewUtils getAllLoginPages]) {
        if ([page rangeOfString:loginPage options:NSCaseInsensitiveSearch].location != NSNotFound) {
            return true;
        }
    }
    return false;
}

+ (BOOL)isPageTimedOut:(NSString *)page {
    if (![NSString isStringEmpty:page] &&
        [page rangeOfString:kPageLoadTimeout
                    options:NSCaseInsensitiveSearch]
                .location != NSNotFound) {
        return true;
    }
    return false;
}

+ (BOOL)doesContainFormTag:(NSString *)HTML {
    // Sometimes the HTML response returned is in the form <html><head></head><body></body></html>.
    // All valid HTMLs in Bridge contain a form tag with the name of the page to navigate to.
    if (![NSString isStringEmpty:HTML] && [HTML rangeOfString:kFormTag options:NSCaseInsensitiveSearch].location != NSNotFound) {
        // This is our javascript error page...we want to show this one.
        return true;
    }
    return false;
}

+ (BOOL)isErrorPage:(NSString *)page {
    if (![NSString isStringEmpty:page] && [page rangeOfString:kWebErrorString options:NSCaseInsensitiveSearch].location != NSNotFound) {
        // This is our javascript error page...we want to show this one.
        return true;
    }
    return false;
}

+ (BOOL)containsServerError:(NSString *)page {
    if ([NSString isStringEmpty:page]) {
        return false;
    }

    if ([page rangeOfString:kWebErrorString options:NSCaseInsensitiveSearch].location != NSNotFound) {
        // This is our javascript error page...we want to show this one.
        return [page rangeOfString:kWebKitError options:NSCaseInsensitiveSearch].location != NSNotFound ? true : false;
    }

    if ([page rangeOfString:kServerError options:NSCaseInsensitiveSearch].location != NSNotFound ||
        [page rangeOfString:kHTTPStatus].location != NSNotFound ||
        [page rangeOfString:kHTTPError].location != NSNotFound) {
        return true;
    }

    return false;
}

+ (BOOL)isPasswordPage:(NSString *)pageURL {
    NSURL *url         = [NSURL URLWithString:pageURL];
    NSString *pageName = [url lastPathComponent];
    if ([[MainViewUtils getAllPasswordPages] containsObject:pageName]) {
        return true;
    }
    return false;
}

@end
