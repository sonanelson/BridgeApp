//
//  main.m
//  TabView
//
//  Created by Bechtold,Brian on 10/15/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "AppDelegate.h"
#import "InactivityApplication.h"

int main(int argc, char *argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, NSStringFromClass([InactivityApplication class]), NSStringFromClass([AppDelegate class]));
    }
}
