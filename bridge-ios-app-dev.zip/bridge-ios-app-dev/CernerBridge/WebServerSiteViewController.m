//
//  WebServerSiteViewController.m
//  Cerner Bridge
//
//  Created by Bechtold,Brian on 8/20/15.
//  Copyright (c) 2015 Bechtold,Brian. All rights reserved.
//

#import "WebServerSiteViewController.h"
#import "BridgeCommonConstants.h"
#import "MainViewController.h"

// Helpers
#import "AlertViewUtils.h"
#import "NSString+Additions.h"
#import "NSUserDefaults+BridgeAdditions.h"
#import "UIColor+BridgeColors.h"
#import "UIViewController+TopmostPresentedViewController.h"

@interface WebServerSiteViewController ()
/**
 * Enum for status codes.
 */
typedef NS_ENUM(NSInteger, StatusCode) {
    kStatusCode_Cancelled = -999,
    kStatusCode_Success   = 200
};
/**
 * IBOutlet for the web server name text field.
 **/
@property (weak, nonatomic) IBOutlet UITextField *textWebServerName;
/**
 * IBOutlet for the web site name text field.
 **/
@property (weak, nonatomic) IBOutlet UITextField *textWebSiteName;
/**
 * IBOutlet for the right bar button item.
 */
@property (nonatomic, strong) IBOutlet UIBarButtonItem *doneButton;
/**
 * An instance of the activity indicator shown when the request is loading.
 */
@property (nonatomic, strong) UIActivityIndicatorView *loadingActivityIndicator;
/**
 * An instance of the session started when the done button is pressed.
 */
@property (nonatomic, strong) NSURLSessionDataTask *doneSessionTask;
@end

@implementation WebServerSiteViewController

+ (UINavigationController *)createContainingNavigationController {
    return [[UIStoryboard storyboardWithName:@"Main" bundle:nil] instantiateInitialViewController];
}

- (void)addActivityIndicator {
    if (self.loadingActivityIndicator != nil) {
        return;
    }

    self.loadingActivityIndicator = [[UIActivityIndicatorView alloc] initWithActivityIndicatorStyle:UIActivityIndicatorViewStyleMedium];
    [self.loadingActivityIndicator setHidesWhenStopped:true];
    [self.loadingActivityIndicator setColor:[UIColor defaultTextColor]];
    self.navigationItem.rightBarButtonItem = [[UIBarButtonItem alloc] initWithCustomView:self.loadingActivityIndicator];
}

- (NSURL *)setUpLoginURL {
    NSString *server = self.textWebServerName.text;
    NSString *site   = self.textWebSiteName.text;

    // Set up URL to open and show error if not valid.
    return [NSURL URLWithString:[NSString getLoginURLForApplication:NULL withServer:server andSite:site]];
}

#pragma mark -
#pragma mark General methods

- (void)viewDidLoad {
    [super viewDidLoad];

    self.doneSessionTask = nil;

    if (![NSUserDefaults getSettingsDictionary]) {
        // If web settings are not set, we need to set them first.
        if (![NSUserDefaults areWebServerDefaultsAlreadySet]) {
            return;
        }
    } else {
        self.textWebServerName.text = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_WebServerName];
        self.textWebSiteName.text   = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_WebSiteName];

        // Set up URL to open and show error if not valid.
        NSURL *url = [self setUpLoginURL];

        // If url is invalid, show an alert.
        if (url == nil) {
            [self showAlertForWebSettingAlertType:kWebSettingAlertType_InvalidURL withErrorDescription:NULL];
            return;
        }

        // If URL is valid, set up a request.
        //[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
        [self setUpSessionWithURL:url];
    }

    self.textWebServerName.text = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_WebServerName];
    self.textWebSiteName.text   = [[NSUserDefaults standardUserDefaults] objectForKey:kDefaultsKey_WebSiteName];
}

#pragma mark -
#pragma mark General methods

- (BOOL)checkIfFieldsAreEmpty {
    // If they are not empty, we don't need to do anything.
    if (![NSString isStringEmpty:self.textWebServerName.text] && ![NSString isStringEmpty:self.textWebSiteName.text]) {
        return NO;
    }

    // Else, show an alert.
    [self showAlertForWebSettingAlertType:kWebSettingAlertType_EmptyField withErrorDescription:NULL];
    return YES;
}

- (void)showAlertForWebSettingAlertType:(WebSettingAlertType)type withErrorDescription:(NSString *)errorDescription {
    UIAlertController *alertController = [AlertViewUtils alertForWebSettingAlertType:type withErrorDescription:errorDescription];
    [[UIViewController topmostViewController] presentViewController:alertController animated:YES completion:nil];
}

- (void)handleError:(NSError *)error {
    // Display alert for the error.
    //[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    [self showAlertForWebSettingAlertType:kWebSettingAlertType_Error withErrorDescription:error.localizedDescription];
}

- (void)handleSuccess {
    NSString *server = self.textWebServerName.text;
    NSString *site   = self.textWebSiteName.text;

    // Do not set the user defaults if there is an error or if the status code is not valid.
    // Set the values in the local preferences.
    [[NSUserDefaults standardUserDefaults] setObject:server forKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] setObject:site forKey:kDefaultsKey_WebSiteName];

    [self.delegate loadLoginPageBasedOnWebSettings];
    [self dismissViewControllerAnimated:NO completion:nil];
}

#pragma mark -
#pragma mark NSURLSession methods

- (void)setUpSessionWithURL:(NSURL *)url {
    // Display activity indicator as an indication of the request being made.
    [self addActivityIndicator];
    [self.loadingActivityIndicator startAnimating];

    // Update request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    [request setHTTPMethod:@"HEAD"];
    request.timeoutInterval = [NSUserDefaults getPageTimeoutFromUserDefaults];

    __weak WebServerSiteViewController *weakSelf = self;

    NSURLSession *session = [NSURLSession sharedSession];

    self.doneSessionTask = [session dataTaskWithRequest:request
                                      completionHandler:^(NSData *_Nullable data, NSURLResponse *_Nullable response, NSError *_Nullable error) {
                                          __strong WebServerSiteViewController *strongSelf = weakSelf;

                                          // Stop the activity indicator.
                                          dispatch_async(dispatch_get_main_queue(), ^{
                                              strongSelf.navigationItem.rightBarButtonItem = weakSelf.doneButton;

                                              if ([strongSelf.loadingActivityIndicator isAnimating]) {
                                                  [strongSelf.loadingActivityIndicator stopAnimating];
                                              }
                                          });

                                          // If it is an error, show an alert with the error.
                                          if (error != NULL) {
                                              // If the session is cancelled, do not show an error and continue.
                                              if (error.code == kStatusCode_Cancelled) {
                                                  return;
                                              }

                                              // Else, display alert for the error.
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [strongSelf handleError:error];
                                              });
                                              return;
                                          }

                                          NSInteger statusCode = [(NSHTTPURLResponse *)response statusCode];
                                          // If response is valid i.e with pass status, navigate to the next appropriate page.
                                          if (statusCode == kStatusCode_Success) {
                                              dispatch_async(dispatch_get_main_queue(), ^{
                                                  [strongSelf handleSuccess];
                                              });
                                              return;
                                          }

                                          // If response is invalid or with fail status, show an alert with the response code.
                                          dispatch_async(dispatch_get_main_queue(), ^{
                                              [strongSelf showAlertForWebSettingAlertType:kWebSettingAlertType_InvalidResponse
                                                                     withErrorDescription:[NSHTTPURLResponse localizedStringForStatusCode:statusCode]];
                                          });
                                      }];
    [self.doneSessionTask resume];
}

#pragma mark -
#pragma mark IBActions

- (IBAction)done:(id)sender {
    // If the fields are empty, show an alert and return.
    if ([self checkIfFieldsAreEmpty]) {
        return;
    }

    // Set up URL to open and show error if not valid.
    NSURL *url = [self setUpLoginURL];

    // If url is invalid, show an alert.
    if (url == nil) {
        [self showAlertForWebSettingAlertType:kWebSettingAlertType_InvalidURL withErrorDescription:NULL];
        return;
    }

    // If URL is valid, set up a request.
    //[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    [self setUpSessionWithURL:url];
}

- (IBAction)textFieldDidChange:(id)sender {
    // If this is just normal typing, don't do anything.
    // If we have already made a request, we need to cancel it and make a new request with the updated text.
    if (![self.loadingActivityIndicator isAnimating]) {
        return;
    }

    [self.loadingActivityIndicator stopAnimating];
    self.loadingActivityIndicator = nil;

    self.navigationItem.rightBarButtonItem = self.doneButton;

    self.loadingActivityIndicator = nil;

    if (self.doneSessionTask == nil) {
        return;
    }

    // Cancel ongoing session with previous request URL.
    [self.doneSessionTask cancel];
}

@end
