//
//  HTMLParser.m
//  CernerBridge
//
//  Created by Shoemake,Andrew on 9/13/18.
//  Copyright © 2018 DWx CareAware Connect. All rights reserved.
//

#import "HTMLParser.h"

#include <libxml/HTMLparser.h>
#include <libxml/HTMLtree.h>
#include <libxml/parser.h>
#include <libxml/tree.h>
#include <libxml/xpath.h>

@implementation HTMLParser

- (NSArray<HTMLElement *> *)elementsFromHTML:(NSString *)html withXPath:(NSString *)xPathQualifier {
    htmlDocPtr doc;
    doc = htmlReadMemory([html UTF8String], (int)html.length, NULL, NULL, 0);

    if (doc == NULL) {
        return @[];
    }

    xmlXPathContextPtr xpathCtx;
    xmlXPathObjectPtr xpathObj;

    xpathCtx = xmlXPathNewContext(doc);

    if (xpathCtx == NULL) {
        xmlFreeDoc(doc);
        return @[];
    }

    xpathObj = xmlXPathEvalExpression((const unsigned char *)[xPathQualifier UTF8String], xpathCtx);

    if (xpathObj == NULL) {
        xmlXPathFreeContext(xpathCtx);
        xmlFreeDoc(doc);
        return @[];
    }

    if (xpathObj->type != XPATH_NODESET) {
        xmlXPathFreeObject(xpathObj);
        xmlXPathFreeContext(xpathCtx);
        xmlFreeDoc(doc);
        return @[];
    }

    NSMutableArray<HTMLElement *> *elements = [NSMutableArray array];

    for (NSUInteger i = 0; i < xpathObj->nodesetval->nodeNr; i++) {
        xmlNodePtr node      = xpathObj->nodesetval->nodeTab[i];
        HTMLElement *element = [self elementFromNode:node];
        [elements addObject:element];
    }

    xmlXPathFreeObject(xpathObj);
    xmlXPathFreeContext(xpathCtx);
    xmlFreeDoc(doc);

    return elements;
}

- (HTMLElement *)elementFromNode:(xmlNodePtr)node {
    NSString *nodeType;
    NSMutableDictionary *nodeProperties = [NSMutableDictionary dictionary];
    NSString *content;

    // Read node type
    if (node->type == XML_ELEMENT_NODE) {
        nodeType = [self typeFromElementNode:node];
    }

    // Read node properties
    xmlAttr *attr = node->properties;
    while (attr != NULL) {
        NSString *key   = [self keyFromXmlAttr:attr];
        NSString *value = [self valueFromXmlAttr:attr];
        [nodeProperties setObject:value forKey:key];
        attr = attr->next;
    }

    // Get node content
    xmlNode *child = node->children;
    while (child != NULL) {
        if (child->type == XML_TEXT_NODE) {
            content = [self stringFromXMLChar:child->content];
            break;
        }
        child = child->next;
    }

    HTMLElement *element = [[HTMLElement alloc] initWithElementType:nodeType properties:nodeProperties text:content];
    return element;
}

- (NSString *)typeFromElementNode:(xmlNodePtr)node {
    return [self stringFromXMLChar:node->name];
}

- (NSString *)keyFromXmlAttr:(xmlAttr *)attr {
    return [self stringFromXMLChar:attr->name];
}

- (NSString *)valueFromXmlAttr:(xmlAttr *)attr {
    xmlNodePtr child = attr->children;
    if (child == NULL) {
        return @"";
    }
    if (child->type == XML_TEXT_NODE) {
        return [self stringFromXMLChar:child->content];
    }
    return @"";
}

- (NSString *)stringFromXMLChar:(const unsigned char *)xmlChar {
    if (xmlChar == NULL) {
        return @"";
    }
    return [NSString stringWithUTF8String:(const char *)xmlChar];
}
@end
