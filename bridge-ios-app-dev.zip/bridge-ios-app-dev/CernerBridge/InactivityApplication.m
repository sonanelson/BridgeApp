//
//  INACTIVITYUIApplication.m
//  Cerner Bridge
//
//  Created by Bechtold,Brian on 11/5/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import "InactivityApplication.h"
#import "BridgeCommonConstants.h"

@interface InactivityApplication ()
/**
 * An instance of the application idle timer.
 */
@property (nonatomic, strong) NSTimer *idleTimer;
/**
 * Boolean to verify if the timeout is enabled.
 */
@property (nonatomic, assign) BOOL isTimeoutEnabled;
@end

@implementation InactivityApplication

#pragma mark - UIApplication Methods

- (void)sendEvent:(UIEvent *)event {
    [super sendEvent:event];

    // If the timer is null, do nothing.
    if (self.idleTimer) {
        return;
    }

    // Here, we are listening for any touch.
    // If the screen receives touch, the timer is reset.
    NSSet *allTouches = [event allTouches];
    if (allTouches.count <= 0) {
        return;
    }

    UITouchPhase phase = ((UITouch *)[allTouches anyObject]).phase;
    if (phase != UITouchPhaseBegan) {
        return;
    }

    [self resetIdleTimer];
}

#pragma mark - General Methods

- (void)resetIdleTimer {
    // Invalidate timer if there is a ongoing idle timer.
    if (self.idleTimer) {
        [self.idleTimer invalidate];
        self.idleTimer = nil;
    }

    if (self.isTimeoutEnabled == FALSE || self.applicationTimeout <= 0) {
        return;
    }

    // Convert the wait period into minutes rather than seconds
    NSTimeInterval timeout = self.applicationTimeout * 60;
    self.idleTimer         = [NSTimer scheduledTimerWithTimeInterval:timeout target:self selector:@selector(idleTimerExceeded) userInfo:nil repeats:NO];
}

- (void)enableIdleTimer {
    if (self.applicationTimeout > 0) {
        self.isTimeoutEnabled = TRUE;
    }
    [self resetIdleTimer];
}

- (void)disableIdleTimer {
    if (!self.isTimeoutEnabled) {
        return;
    }

    self.isTimeoutEnabled = FALSE;
    [self resetIdleTimer];
}

- (void)idleTimerExceeded {
    if (!self.isTimeoutEnabled) {
        return;
    }

    // If the timer reaches the limit, as defined in kApplicationTimeoutInMinutes, post this notification
    [[NSNotificationCenter defaultCenter] postNotificationName:kNotification_ApplicationDidTimeout object:nil];
}

@end
