//
//  INACTIVITYUIApplication.h
//  Cerner Bridge
//
//  Created by Bechtold,Brian on 11/5/12.
//  Copyright (c) 2012 Bechtold,Brian. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface InactivityApplication : UIApplication
/**
 * The application timeout value.
 */
@property (nonatomic, assign) NSInteger applicationTimeout;

/**
 * Enable the application idle timer.
 */
- (void)enableIdleTimer;
/**
 * Disable the application idle timer.
 */
- (void)disableIdleTimer;
@end
