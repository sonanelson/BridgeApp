//
//  BridgeCommonConstants.h
//  CernerBridge
//
//  Created by Gore,Divya on 11/8/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#ifndef BridgeCommonConstants_h
#define BridgeCommonConstants_h

// Keys
static NSString *const NEW_RELIC_TOKEN_KEY = @"NewRelicToken";

// Javascript
static NSString *const kVisibilityScript   = @"javascript:document.getElementById('%@').style.visibility = 'hidden';";
static NSString *const kClickScript        = @"document.getElementById('%@').click();";
static NSString *const kHelpScript         = @"window.location=document.getElementById('%@').href;";
static NSString *const kDocumentOuterHTML  = @"document.documentElement.outerHTML";
static NSString *const kAlertActionScript  = @"window.alert = function(message) { window.location = \"http://action/alert?message=\" + message; }";
static NSString *const kAlertConfirmScript = @"window.confirm = function(message) { window.location = \"http://action/confirm?message=\" + message; }";
static NSString *const kWebViewCreate      = @"var meta = document.createElement('meta');\
                                                   meta.name = 'viewport';\
                                                   meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';\
                                                   var head = document.getElementsByTagName('head')[0];head.appendChild(meta);";

// Constants
static NSString *const kPatientsLink       = @"lnkchangepatient";
static NSString *const kHomeLink           = @"lnkhome";
static NSString *const kCancel             = @"cancel";
static NSString *const kContinue           = @"continue";
static NSString *const kNo                 = @"cmdno";
static NSString *const kYes                = @"cmdyes";
static NSString *const kOk                 = @"ok";
static NSString *const kLogoutLink         = @"lnkLogout";
static NSString *const kBackLink           = @"backbtn";
static NSString *const kFilter             = @"btnAddPoc";
static NSString *const kScan               = @"scan";
static NSString *const kInfo               = @"lnkInfo";
static NSString *const kAutoLogTime        = @"autologtime";
static NSString *const kAvailableSolutions = @"availablesolutions";

// URL Format
static NSString *kFormat_URLLogin       = @"%@://%@/%@/HandHeld/%@.aspx?TimeZone=%@";
static NSString *const kURLPath_Alert   = @"/alert";
static NSString *const kURLPath_Confirm = @"/confirm";

// The Managed app configuration dictionary pushed down from an MDM server are stored in this key.
static NSString *const kMDMConfigurationKey = @"com.apple.configuration.managed";

// Global user defaults
static NSString *const kDefaultsKey_EnableSSL     = @"enableSSL";
static NSString *const kDefaultsKey_WebServerName = @"WebServerName";
static NSString *const kDefaultsKey_WebSiteName   = @"WebSiteName";
static NSString *const kDefaultsKey_CodeCorpKey   = @"CodeCorpKey";

// Notification
static NSString *const kNotification_ApplicationDidTimeout = @"AppTimeOut";

// Login Pages
static NSString *kLoginPage_Default   = @"Login";
static NSString *kLoginPage_BabyMatch = @"BabyMatch/Login";
static NSString *kLoginPage_DonorMilk = @"DonorMilk/Login";
static NSString *kLoginPage_MedAdmin  = @"hhwelcome.do";
static NSString *kLogoutPage_Default  = @"logout";
static NSString *kLogoutPage_MedAdmin = @"hhautoLogout.do";

// Localization Table Name
static NSString *const kTable_Localization = @"BridgeLocalization";

#endif /* BridgeCommonConstants_h */
