//
//  MainWebView.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/9/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "MainWebView.h"
#import "BridgeCommonConstants.h"

// Delegates
#import "WebViewMainViewDelegate.h"
#import "WebViewNavigationBarDelegate.h"

// Categories
#import "HTMLParser+XPathHelper.h"
#import "NSMutableDictionary+AlertViewHelper.h"
#import "NSString+Additions.h"
#import "NSUserDefaults+BridgeAdditions.h"
#import "SoundUtils.h"
#import "UIApplication+TypeAdditions.h"

// Helpers
#import "AlertViewUtils.h"
#import "MainViewUtils.h"

// Error Strings
static NSString *const kServerError = @"Server Error";
static NSString *const kErrorString = @"An error occurred:";
static NSString *const kAutoLogout  = @"autoLogTime";
static NSString *const kErrorText   = @"errorText";

// URL Path Strings
static NSString *const kURLHost_Action  = @"action";
static NSString *const kURLDomain_Error = @"NSURLErrorDomain";

@interface MainWebView () <WKUIDelegate, WKNavigationDelegate>
/**
 * The last URL that was loaded in the web page.
 */
@property (nonatomic, strong) NSString *lastURL;
/**
 * The timer that times how long the page has been idle.
 */
@property (nonatomic, strong) NSTimer *pageTimer;
/**
 * The current page timeout value.
 */
@property (nonatomic, assign) NSInteger pageTimeoutVal;
/**
 * IBOutlet for the activity indicator for indicating the loading of the current page.
 */
@property (nonatomic, strong) IBOutlet UIActivityIndicatorView *activityIndicator;

@end

@implementation MainWebView

#pragma mark -
#pragma mark Load/ Unload methods

- (void)awakeFromNib {
    [super awakeFromNib];
    [self initialize];
}

- (void)initialize {
    self.navigationDelegate = self;
    self.pageTimeoutVal     = [NSUserDefaults getPageTimeoutFromUserDefaults];
}

- (void)unload {
    self.navigationDelegate           = nil;
    self.webViewMainViewDelegate      = nil;
    self.webViewNavigationBarDelegate = nil;
    self.pageTimer                    = nil;
    //[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;

    if (![self isLoading]) {
        return;
    }
    [self stopLoading];

    if ([self.activityIndicator isAnimating]) {
        [self.activityIndicator stopAnimating];
    }
}

#pragma mark -
#pragma mark General methods

- (void)loadURL:(NSURL *)URL shouldSetLastURL:(BOOL)shouldSet {
    [self.activityIndicator startAnimating];

    // Set up page timer here.
    // Sometimes, the request itself does not go through and we need to account for that.
    [self setUpTimer];

    NSURLComponents *components = [NSURLComponents componentsWithString:URL.absoluteString];

#ifdef RELEASE_PRODUCTION

    components.scheme = @"https";

#else

    components.scheme = [[NSUserDefaults standardUserDefaults] boolForKey:kDefaultsKey_EnableSSL] ? @"https" : @"http";

#endif

    URL = components.URL;

    if (shouldSet) {
        self.lastURL = URL.absoluteString;
    }

    NSURLRequest *request   = [NSURLRequest requestWithURL:URL];
    self.navigationDelegate = self;
    [self loadRequest:request];
}

- (void)setApplicationTimeoutForPage:(NSString *)HTML {
    // Return if the current page HTML is empty or if it is not a logout html.
    if ([NSString isStringEmpty:HTML] || ![HTML caseInsensitiveSearchForText:kAutoLogout]) {
        return;
    }

    // Parse the logout time from the given HTML.
    HTMLElement *element = [HTMLParser getAutoLogoutTimeFromHTML:HTML];
    if (element == nil) {
        return;
    }

    // The text is in the for test = '^<number>'.
    NSInteger autoLogoutMin = [[element.text substringFromIndex:1] intValue];
    if (autoLogoutMin != INT_MAX && autoLogoutMin != INT_MIN) {
        [[UIApplication inactivityApplication] setApplicationTimeout:autoLogoutMin];
    }
}

- (void)parseAlertDetailsBasedOnHTML:(NSString *)HTML {
    // Return if current page HTML is empty or if it does not contain any error.
    if ([NSString isStringEmpty:HTML] || ![HTML caseInsensitiveSearchForText:kErrorText]) {
        return;
    }

    // Get alert elements from the current page.
    NSArray<HTMLElement *> *elements = [HTMLParser getErrorAlertInfoFromHTML:HTML];
    if (elements.count == 0) {
        return;
    }

    // Play Sound.
    [SoundUtils playDefaultAlertSound];

    // The alert will always be in the form:: javascript:alert(\"Title<br>btn:buttonTitle<br>message\");
    UIAlertController *controller = [AlertViewUtils alertFromHTMLElements:elements];
    [self.webViewMainViewDelegate presentAlertController:controller
                                        withActionTitles:[AlertViewUtils alertButtonTitlesFromElements:elements]
                                                 andInfo:@{kKey_Response_ServerError: [NSNumber numberWithBool:NO]}];
}

- (BOOL)checkWebSettingsExist {
    if ([NSUserDefaults areWebServerDefaultsAlreadySet]) {
        return YES;
    }
    [self.webViewMainViewDelegate displayWebSettingsErrorPage];
    return NO;
}

- (BOOL)updateElementsBasedOnServerErrorForPage:(NSString *)page withURL:(NSString *)URL {
    if (![MainViewUtils containsServerError:page]) {
        return NO;
    }

    [[UIApplication inactivityApplication] disableIdleTimer];
    [self handleErrorPage:kServerError url:URL];
    [self.webViewNavigationBarDelegate adjustVisibilityOfAppMenuIcon:false];
    return YES;
}

- (void)processElementsOnPage:(NSString *)page withURL:(NSString *)URL {
    if ([MainViewUtils isStartPage:URL]) {
        [[UIApplication inactivityApplication] disableIdleTimer];
        [self setApplicationTimeoutForPage:page];

        // If settings have not previously been set, set them based on the "availableSolutions" on the Login.aspx.
        NSInteger appCount = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:page];
        [self.webViewNavigationBarDelegate adjustVisibilityOfAppMenuIcon:(appCount <= 1)];
        return;
    }

    [[UIApplication inactivityApplication] enableIdleTimer];
    BOOL shouldShowMenuButton = [page caseInsensitiveSearchForText:kErrorString];
    [self.webViewNavigationBarDelegate adjustVisibilityOfAppMenuIcon:!shouldShowMenuButton];
}

- (void)processAlertDetailsFromText:(NSString *)text forConfirmAlert:(BOOL)isConfirm {
    NSMutableArray *lines        = [NSMutableArray arrayWithArray:[text componentsSeparatedByString:@"<br>"]];
    NSString *title              = @"";
    NSString *okResponse         = @"";
    NSString *cancelResponse     = @"";
    NSMutableDictionary *details = [NSMutableDictionary dictionaryWithCapacity:3];
    for (NSInteger i = 0; i < lines.count; i++) {
        /*Confirm Dialog has the following format:
         ConfirmURL<br>CancelURL<br>title<br>btn:ok text<br>btn2:cancel Text<br>Msg line1<br>Msg Line2...
         The ok text and cancel text begins in 2015.01.02, earlier versions send message lines instead of
         the ok text and cancel text, so code below can handle either case. */
        if (isConfirm) {
            switch (i) {
            case 0:
                okResponse = lines[i];
                break;

            case 1:
                cancelResponse = lines[i];
                break;

            case 2:
                title = lines[i];
                break;

            default: {
                // The messages are normally multi-line and seprated by <br>.
                // That is why we need to append the messages here.
                NSString *message = [details objectForKey:kKey_Alert_Message] ? details[kKey_Alert_Message] : @"";
                [details getAlertButtonTitlesFromText:lines[i] appendToMessage:message forConfirmAlert:true];
            } break;
            }
        } else {
            switch (i) {
            case 0:
                title = lines[i];
                break;

            default: {
                // The messages are normally multi-line and seprated by <br>.
                // That is why we need to append the messages here.
                NSString *message = [details objectForKey:kKey_Alert_Message] ? details[kKey_Alert_Message] : @"";
                [details getAlertButtonTitlesFromText:lines[i] appendToMessage:message forConfirmAlert:false];
            } break;
            }
        }
    }

    // Present alert based on the above information.
    NSDictionary *info = [NSMutableDictionary createWithServerError:NO cancelResponse:cancelResponse andOkResponse:okResponse];
    [self presentAlertWithTitle:title details:details andOtherInfo:info];
}

- (void)presentAlertWithTitle:(NSString *)title details:(NSDictionary *)details andOtherInfo:(NSDictionary *)info {
    UIAlertController *controller = [AlertViewUtils alertWithTitle:title details:details];
    [self.webViewMainViewDelegate presentAlertController:controller withActionTitles:[AlertViewUtils alertButtonTitlesFromDetails:details] andInfo:info];
}

- (NSInteger)getMessageIndexFromURL:(NSURL *)URL {
    // Parsing the url and get the message, assume there is a '='for value, if you are passing multiple value, you might need to do more
    NSInteger index   = -1;
    NSString *message = [[URL query] stringByRemovingPercentEncoding];
    index             = [message getIndexOfText:@"="];
    return index;
}

- (BOOL)isNavigationPolicyAllowForURL:(NSURL *)url {
    // If it is a normal page, allow navigation.
    if (![url.host isEqualToString:kURLHost_Action]) {
        return true;
    }

    // If it is not a normal alert or a confirmation dialog, allow navigation.
    BOOL isAlert   = [url.path isEqualToString:kURLPath_Alert];
    BOOL isConfirm = [url.path isEqualToString:kURLPath_Confirm];
    if (!isAlert && !isConfirm) {
        return true;
    }

    // Parsing the url and get the message, assume there is a '='for value, if you are passing multiple value, you might need to do more
    NSInteger iStart = [self getMessageIndexFromURL:url];
    // If message is not found, then it means it is a normal page. So, allow navigation.
    if (iStart <= 0) {
        return true;
    }
    return false;
}

#pragma mark -
#pragma mark Error handlings

- (void)handleErrorPage:(NSString *)error url:(NSString *)currentURL {
    [self.webViewNavigationBarDelegate adjustVisibilityOfAppMenuIcon:false];

    // Report the error inside the webview, if login page, show alert, if any other page, give option to retry or logout.
    NSString *loginURL = self.applicationURL;

    BOOL isStartPage = [MainViewUtils isStartPage:currentURL];
    if (isStartPage && ![self checkWebSettingsExist]) {
        return;
    }

    ErrorAlertType alertType      = isStartPage ? kErrorAlertType_Server : kErrorAlertType_General;
    UIAlertController *controller = [AlertViewUtils alertWithErrorType:alertType andMessage:error];
    NSDictionary *info            = [NSMutableDictionary createWithServerError:isStartPage cancelResponse:loginURL andOkResponse:self.lastURL];
    [self.webViewMainViewDelegate presentAlertController:controller withActionTitles:[AlertViewUtils alertButtonTitlesWithLogout:!isStartPage] andInfo:info];
}

#pragma mark -
#pragma mark Timer

- (void)setUpTimer {
    __weak MainWebView *weakSelf = self;
    self.pageTimer               = [NSTimer scheduledTimerWithTimeInterval:self.pageTimeoutVal
                                                     repeats:NO
                                                       block:^(NSTimer *_Nonnull timer) {
                                                           [weakSelf pageTimerExceeded];
                                                       }];
}

- (void)setPageTimer:(NSTimer *)pageTimer {
    if (_pageTimer != nil) {
        [_pageTimer invalidate];
        _pageTimer = nil;
    }

    _pageTimer = pageTimer;
}

- (void)pageTimerExceeded {
    if (![self isLoading] && ![self.activityIndicator isAnimating]) {
        return;
    }

    if ([self isLoading]) {
        [self stopLoading];
    }

    if ([self.activityIndicator isAnimating]) {
        [self.activityIndicator stopAnimating];
    }

    NSString *loginURL           = self.applicationURL;
    __weak MainWebView *weakSelf = self;
    [self evaluateJavaScript:kDocumentOuterHTML
           completionHandler:^(id _Nullable result, NSError *_Nullable error) {
               NSString *HTML = (NSString *)result;
               if ([MainViewUtils isPageTimedOut:HTML] || [MainViewUtils containsServerError:HTML] || [MainViewUtils isErrorPage:HTML]) {
                   return;
               }

               [weakSelf.webViewNavigationBarDelegate adjustVisibilityOfAppMenuIcon:false];

               BOOL hasLoggedIn              = ![MainViewUtils isStartPage:HTML] && ![MainViewUtils isPasswordPage:HTML] && [MainViewUtils doesContainFormTag:HTML];
               UIAlertController *controller = [AlertViewUtils alertWithErrorType:kErrorAlertType_PageTimeoutError andMessage:(!hasLoggedIn ? kErrorString : NULL)];
               NSDictionary *info            = [NSMutableDictionary createWithServerError:NO cancelResponse:loginURL andOkResponse:self.lastURL];
               [self.webViewMainViewDelegate presentAlertController:controller withActionTitles:[AlertViewUtils alertButtonTitlesWithLogout:hasLoggedIn] andInfo:info];

               weakSelf.pageTimer = nil;
           }];
}

#pragma mark -
#pragma mark WKWebViewNavigation Delegate

- (void)webView:(WKWebView *)webView didCommitNavigation:(null_unspecified WKNavigation *)navigation {
    // starting the load, show the activity indicator in the status bar
    //[UIApplication sharedApplication].networkActivityIndicatorVisible = YES;
    self.userInteractionEnabled = NO;

    // Set timer here to because the loadURl method is not always called.
    [self setUpTimer];

    // This lets WKWebView present content like UIWebView used to do
    WKUserScript *script = [[WKUserScript alloc] initWithSource:kWebViewCreate injectionTime:WKUserScriptInjectionTimeAtDocumentEnd forMainFrameOnly:NO];
    [webView.configuration.userContentController addUserScript:script];
}

- (void)webView:(WKWebView *)webView didFinishNavigation:(null_unspecified WKNavigation *)navigation {
    if ([self.activityIndicator isAnimating]) {
        [self.activityIndicator stopAnimating];
    }

    // finished loading, hide the activity indicator in the status bar
    self.pageTimer = nil;

    self.userInteractionEnabled = YES;
    //[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;

    __weak MainWebView *weakSelf = self;
    NSString *currentURL         = self.URL.absoluteString;
    [webView evaluateJavaScript:kDocumentOuterHTML
              completionHandler:^(id _Nullable result, NSError *_Nullable error) {
                  [weakSelf fixWebFormValidation];

                  NSString *currentHtml = (NSString *)result;
                  // Check for Server error and display error alert.
                  if ([weakSelf updateElementsBasedOnServerErrorForPage:currentHtml withURL:currentURL]) {
                      return;
                  }

                  weakSelf.lastURL = currentURL;
                  // Process elements or show errors based on the current page.
                  [weakSelf processElementsOnPage:currentHtml withURL:currentURL];

                  // Update the UI with navigation bar buttons, bottom bar buttons and title for the current page.
                  [weakSelf.webViewMainViewDelegate updateUIForPage:currentHtml withURL:currentURL];

                  // This javascript is needed when we click on any row and need to trigger an action to display required info.
                  [webView evaluateJavaScript:kAlertActionScript completionHandler:nil];
                  [webView evaluateJavaScript:kAlertConfirmScript completionHandler:nil];

                  // Parse, process and present alert with the required alert.
                  [weakSelf parseAlertDetailsBasedOnHTML:currentHtml];
              }];
}

- (void)webView:(WKWebView *)webView
    decidePolicyForNavigationAction:(WKNavigationAction *)navigationAction
                    decisionHandler:(void (^)(WKNavigationActionPolicy))decisionHandler;
{
    NSURL *url = navigationAction.request.URL;
    if ([self isNavigationPolicyAllowForURL:url]) {
        decisionHandler(WKNavigationActionPolicyAllow);
        return;
    }

    // If it is a confirm alert and message is found, then display an alert and do not allow navigation.
    BOOL isConfirm    = [url.path isEqualToString:kURLPath_Confirm];
    NSString *message = [[url query] stringByRemovingPercentEncoding];
    NSInteger iStart  = [self getMessageIndexFromURL:url] + 1;
    [self processAlertDetailsFromText:[message substringFromIndex:iStart] forConfirmAlert:isConfirm];

    decisionHandler(WKNavigationActionPolicyCancel);
    return;
}

- (void)webView:(WKWebView *)webView didFailNavigation:(WKNavigation *)navigation withError:(NSError *)error {
    if ([self.activityIndicator isAnimating]) {
        [self.activityIndicator stopAnimating];
    }

    // load error, hide the activity indicator in the status bar and show the Error page.
    self.pageTimer = nil;

    //[UIApplication sharedApplication].networkActivityIndicatorVisible = NO;
    if (!([error.domain isEqualToString:kURLDomain_Error] && error.code == NSURLErrorCancelled)) {
        [self handleErrorPage:error.localizedDescription url:self.URL.absoluteString];
    }
}

#pragma mark -
#pragma mark Custom JS Scripts

/**
 * Safari WebForms expect date pickers to have a default value set in the format of:
 * yyyy-dd-mmThh:mm
 * The Bridge WebServer can sometimes default them to:
 * yyy-dd-mmThh:mm:ss which will cause Safari WebForms to indicate an error to the user
 *
 * This can be worked around by putting the form into 'noValidate' mode which means
 * Safari/WKWebView will do no client side validate and it will be up to the WebServer
 * to do so.
 *
 * An alternate strategy would be to find all date picker elements and manually adjust the
 * format, but would require that the locale is known along with the proper date time format
 * for that locale.
 *
 * The below method will run a JS script to find all forms on the page and set the 'noValidate'
 * property to true.
 */
- (void)fixWebFormValidation {
    // Forms must be in novalidate mode to prevent safari from throwing errors on date pickers
    NSString *fixFormsScript = @"var formsCollection; \
    var r; \
    formsCollection=document.forms; \
    for(r=0;r<formsCollection.length;r++){ formsCollection[r].noValidate=true; }";
    [self evaluateJavaScript:fixFormsScript completionHandler:nil];
}

@end
