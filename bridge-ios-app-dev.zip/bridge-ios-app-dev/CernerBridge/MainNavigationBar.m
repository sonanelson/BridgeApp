//
//  MainNavigationBar.m
//  CernerBridge
//
//  Created by Gore,Divya on 11/5/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "MainNavigationBar.h"
#import "BridgeCommonConstants.h"

// Delegates
#import "NavigationBarDropDownMenuDelegate.h"
#import "WebActionResponderDelegate.h"

// Utils
#import "HTMLElement+TypeHelper.h"
#import "HTMLParser+XPathHelper.h"
#import "NSString+Additions.h"
#import "UIColor+BridgeColors.h"
#import "UIFont+BridgeFonts.h"

@interface MainNavigationBar ()
/**
 * The ID of the left navigation bar button.
 */
@property (nonatomic, strong) NSString *leftButtonID;
/**
 * The text of the left navigation bar button.
 */
@property (nonatomic, strong) NSString *leftButtonText;
/**
 * Boolean to indicate if the bar button is a filter button or not.
 */
@property (nonatomic, assign) BOOL isFilterButton;
/**
 * Boolean value that indicates if the Menu Button should be hidden or not.
 */
@property (nonatomic, assign) BOOL shouldHideAppMenuButton;
@end

// Strings
static NSString *const kAppMenuID    = @"AppMenu";
static NSString *const kFilterString = @"btnAddPoc";
static NSString *const kBackString   = @"Back";

// Images
static NSString *const kActionMenu  = @"actionIcon";
static NSString *const kFilterImage = @"filterIcon";
static NSString *const kBackArrow   = @"leftArrowIcon";

// Constants
static CGFloat kButtonInset = 5.0f;

@implementation MainNavigationBar

- (void)awakeFromNib {
    [super awakeFromNib];

    self.shouldHideAppMenuButton = true;

    [self resetToDefaults];
}

- (void)adjustVisibilityOfAppMenuIcon:(BOOL)shouldHide {
    self.shouldHideAppMenuButton = shouldHide;
}

- (void)resetToDefaults {
    self.leftButtonID               = @"";
    self.leftButtonText             = @"";
    self.isFilterButton             = false;
    self.topItem.leftBarButtonItem  = NULL;
    self.topItem.rightBarButtonItem = NULL;
}

- (void)parseItemsWithTitle:(NSString *)title fromHTML:(NSString *)HTML {
    // Clean up the navigation bar attributes from the previous page.
    [self resetToDefaults];

    // Parse the navigation bar elements from the current page and
    // set the navigation bar button attributes based on that.
    // The right bar button is always the Action Menu which will always be present.
    NSArray<HTMLElement *> *elements = [HTMLParser getLeftBarButtonNavigationBarElementsFromHTML:HTML];
    for (HTMLElement *element in elements) {
        [self setButtonAttributesFromHTML:element];
    }

    // If there are no elements found, it means that it is the login page.
    // So, we need to set the left bar button to the default App Menu option.
    if (elements.count == 0 && !self.shouldHideAppMenuButton) {
        // Should show AppMenu button.
        self.leftButtonID   = kAppMenuID;
        self.leftButtonText = NSLocalizedStringWithDefaultValue(@"MAIN.NAVBAR.APPLICATIONS.TITLE",
                                                                kTable_Localization,
                                                                [NSBundle mainBundle],
                                                                @"Applications",
                                                                @"Title for Applications button.");
    }

    // Get the title from the current HTML and set all Navigation bar attributes
    HTMLElement *pagetitle = [HTMLParser parseTitleFromHTML:HTML];
    [self setUIAttributesForNavigationBarWithTitle:(pagetitle.text.length > 0 ? pagetitle.text : title)];
}

- (void)setButtonAttributesFromHTML:(HTMLElement *)element {
    // Should show back button.
    if ([element isOfTypeBack]) {
        self.leftButtonID   = element.elementID;
        self.leftButtonText = element.text;
        return;
    }

    // Should show filter button.
    if ([element isOfTypeFilter]) {
        self.leftButtonID   = element.elementID;
        self.leftButtonText = @"";
        self.isFilterButton = true;
        return;
    }

    // Should show back button with custom text.
    if ([element isOfTypeHome] && ![self.leftButtonText caseInsensitiveSearchForText:kBackString]) {
        self.leftButtonID   = element.elementID;
        self.leftButtonText = element.text;
        return;
    }
}

- (void)setUIAttributesForNavigationBarWithTitle:(NSString *)pageTitle {
    // Title
    self.topItem.title = pageTitle;

    // Right Bar button
    self.topItem.rightBarButtonItem = [self createBarButtonWithTag:kNavBarButton_Right withTitle:NULL andImage:[UIImage imageNamed:kActionMenu]];

    // Left Bar Button
    if (self.leftButtonID.length <= 0) {
        return;
    }
    [self setUpLeftBarButton];
}

- (void)setUpLeftBarButton {
    NSInteger buttonTag            = self.shouldHideAppMenuButton ? kNavBarButton_Left : kNavBarButton_Menu;
    NSString *imageName            = self.isFilterButton ? kFilterImage : kBackArrow;
    self.topItem.leftBarButtonItem = [self createBarButtonWithTag:buttonTag withTitle:self.leftButtonText andImage:(self.shouldHideAppMenuButton ? [UIImage imageNamed:imageName] : NULL)];

    // Adjust visibility of the duplicate button on the web page based on ID on the current page.
    [self.actionDelegate performActionBasedOnJavascript:[NSString stringWithFormat:kVisibilityScript, self.leftButtonID]];
}

- (UIBarButtonItem *)createBarButtonWithTag:(NavigationBarButtonTag)tag withTitle:(NSString *)title andImage:(UIImage *)image {
    // Do not add an emoty button with no title or image.
    if ([NSString isStringEmpty:title] && image == nil) {
        return NULL;
    }

    // Set content insets for bigger clickable area for smaller buttons.
    // If the button has text, no need to set side insets.
    UIEdgeInsets contentInsets = UIEdgeInsetsZero;
    contentInsets.top = contentInsets.bottom = kButtonInset;
    if ([NSString isStringEmpty:title]) {
        contentInsets.left = contentInsets.right = kButtonInset * 2;
    }

    // Set attributes for custom bar button.
    UIButton *button = [UIButton buttonWithType:UIButtonTypeCustom];
    [button.titleLabel setFont:[UIFont defaultTitleFont]];
    [button setTag:tag];
    [button setContentEdgeInsets:contentInsets];
    [button setBackgroundColor:[UIColor whiteColor]];
    [button setTintColor:[UIColor defaultTextColor]];
    [button setTitle:title forState:UIControlStateNormal];
    [button setTitleColor:[UIColor defaultTextColor] forState:UIControlStateNormal];
    [button setImage:image forState:UIControlStateNormal];
    [button addTarget:self action:@selector(navigationBarButtonClicked:) forControlEvents:UIControlEventTouchUpInside];
    return [[UIBarButtonItem alloc] initWithCustomView:button];
}

- (void)navigationBarButtonClicked:(UIBarButtonItem *)sender {
    switch (sender.tag) {
    case kNavBarButton_Menu: // App Menu Button
        [self.dropDownMenuDelegate performActionBasedOnNavigationBarButtonClick:kNavBarButton_Menu];
        [self.actionDelegate performShowAppMenuAction];
        break;

    case kNavBarButton_Left: // Left Bar Button (Filter  / Back)
        [self.dropDownMenuDelegate performActionBasedOnNavigationBarButtonClick:kNavBarButton_Left];
        [self.actionDelegate performActionBasedOnJavascript:[NSString stringWithFormat:kClickScript, self.leftButtonID]];
        break;

    case kNavBarButton_Right: // Right Bar button (Action menu)
        [self.dropDownMenuDelegate performActionBasedOnNavigationBarButtonClick:kNavBarButton_Right];
        break;

    default:
        CernLogError(@"Invalid navigation bar button clicked.");
        break;
    }
}

@end
