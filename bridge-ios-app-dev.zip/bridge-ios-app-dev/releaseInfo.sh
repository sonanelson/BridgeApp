#!/bin/sh

#  releaseInfo.sh
#  Bridge iOs
#
#  Created by Shoemake,Andrew 4/11/19
#  Copyright (c) 2019 Cerner Corporation. All rights reserved.

PROD_BUILD_SCHEME="Release-Production"