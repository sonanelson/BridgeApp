//
//  UIFont+BridgeFontsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIFont+BridgeFonts.h"
#import <XCTest/XCTest.h>

@interface UIFont_BridgeFontsTest : XCTestCase

@end

@implementation UIFont_BridgeFontsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testBottomBarFont {
    UIFont *font = [UIFont bottomBarFont];
    XCTAssertTrue([font.fontName isEqualToString:@"OpenSans"]);
    XCTAssertTrue(font.pointSize == 14.0f);
}

- (void)testDropDownMenuFont {
    UIFont *font = [UIFont defaultTitleFont];
    XCTAssertTrue([font.fontName isEqualToString:@"OpenSans"]);
    XCTAssertTrue(font.pointSize == 16.0f);
}

@end
