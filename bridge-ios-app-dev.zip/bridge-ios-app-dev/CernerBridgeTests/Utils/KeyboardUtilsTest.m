//
//  KeyboardUtilsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 1/31/19.
//  Copyright © 2019 Cerner Corporation. All rights reserved.
//

#import <CernerOCMock.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import "KeyboardUtils.h"

@interface KeyboardUtils ()
+ (UIWindow *)getKeyboardAccessoryWindow;
+ (BOOL)doesViewContainSubviews:(UIView *)view;
+ (void)hideKeyboardAccessoryViewInViews:(NSArray *)views;
+ (BOOL)isInputContainerViewPresentInView:(UIView *)view;
@end

@interface KeyboardUtilsTest : XCTestCase
@end

@implementation KeyboardUtilsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testhideWebInputAccessoryForKeyboard {
    UIWindow *window = [UIWindow new];

    OCMockObject *mockKeyboardUtils = [OCMockObject mockForClass:[KeyboardUtils class]];
    [[[mockKeyboardUtils expect] andReturn:window] getKeyboardAccessoryWindow];
    [[[mockKeyboardUtils expect] andReturnValue:@YES] doesViewContainSubviews:OCMOCK_ANY];
    [[[mockKeyboardUtils expect] andReturnValue:@YES] isInputContainerViewPresentInView:OCMOCK_ANY];
    [[mockKeyboardUtils expect] hideKeyboardAccessoryViewInViews:OCMOCK_ANY];

    NSArray *array           = @[[UIView new]];
    OCMockObject *mockWindow = [OCMockObject partialMockForObject:window];
    [[[mockWindow stub] andReturn:array] subviews];

    [KeyboardUtils hideWebInputAccessoryForKeyboard];

    CernerOCMockVerify(mockKeyboardUtils);
    [mockKeyboardUtils stopMocking];
}

- (void)testhideWebInputAccessoryForKeyboard_NoInputContainer {
    UIWindow *window = [UIWindow new];

    OCMockObject *mockKeyboardUtils = [OCMockObject mockForClass:[KeyboardUtils class]];
    [[[mockKeyboardUtils expect] andReturn:window] getKeyboardAccessoryWindow];
    [[[mockKeyboardUtils reject] andReturnValue:@YES] doesViewContainSubviews:OCMOCK_ANY];
    [[[mockKeyboardUtils expect] andReturnValue:@NO] isInputContainerViewPresentInView:OCMOCK_ANY];
    [[mockKeyboardUtils reject] hideKeyboardAccessoryViewInViews:OCMOCK_ANY];

    NSArray *array           = @[[UIView new]];
    OCMockObject *mockWindow = [OCMockObject partialMockForObject:window];
    [[[mockWindow stub] andReturn:array] subviews];

    [KeyboardUtils hideWebInputAccessoryForKeyboard];

    CernerOCMockVerify(mockKeyboardUtils);
    [mockKeyboardUtils stopMocking];
}

- (void)testhideWebInputAccessoryForKeyboard_NoContainerSubviews {
    UIWindow *window = [UIWindow new];

    OCMockObject *mockKeyboardUtils = [OCMockObject mockForClass:[KeyboardUtils class]];
    [[[mockKeyboardUtils expect] andReturn:window] getKeyboardAccessoryWindow];
    [[[mockKeyboardUtils expect] andReturnValue:@NO] doesViewContainSubviews:OCMOCK_ANY];
    [[[mockKeyboardUtils expect] andReturnValue:@YES] isInputContainerViewPresentInView:OCMOCK_ANY];
    [[mockKeyboardUtils reject] hideKeyboardAccessoryViewInViews:OCMOCK_ANY];

    NSArray *array = @[[UIView new]];

    OCMockObject *mockWindow = [OCMockObject partialMockForObject:window];
    [[[mockWindow stub] andReturn:array] subviews];

    [KeyboardUtils hideWebInputAccessoryForKeyboard];

    CernerOCMockVerify(mockKeyboardUtils);
    [mockKeyboardUtils stopMocking];
}

- (void)testDoesViewContainSubviews_YES {
    UIView *view    = [UIView new];
    UIView *subView = [UIView new];

    OCMockObject *mockView = [OCMockObject partialMockForObject:view];
    [[[mockView expect] andReturn:@[subView]] subviews];

    BOOL doesContainSubviews = NO;
    doesContainSubviews      = [KeyboardUtils doesViewContainSubviews:view];

    XCTAssertTrue(doesContainSubviews);
    CernerOCMockVerify(mockView);
    [mockView stopMocking];
}

- (void)testDoesViewContainSubviews_NO {
    UIView *view = [UIView new];

    OCMockObject *mockView = [OCMockObject partialMockForObject:view];
    [[[mockView expect] andReturn:@[]] subviews];

    BOOL doesContainSubviews = YES;
    doesContainSubviews      = [KeyboardUtils doesViewContainSubviews:view];

    XCTAssertFalse(doesContainSubviews);
    CernerOCMockVerify(mockView);
    [mockView stopMocking];
}

- (void)testGetKeyboardAccessoryWindow_nil {
    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[[mockSharedApplication expect] andReturn:@[]] windows];

    UIWindow *kbWindow = [UIWindow new];
    kbWindow           = [KeyboardUtils getKeyboardAccessoryWindow];

    XCTAssertNil(kbWindow);
    [mockSharedApplication stopMocking];
}

- (void)testGetKeyboardAccessoryWindow_windowClass {
    UIWindow *window                    = [UIWindow new];
    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[[mockSharedApplication expect] andReturn:@[window]] windows];

    UIWindow *kbWindow = window;
    kbWindow           = [KeyboardUtils getKeyboardAccessoryWindow];

    XCTAssertNil(kbWindow);
    [mockSharedApplication stopMocking];
}

- (void)testGetKeyboardAccessoryWindow_NotWindowClass {
    UIView *view                        = [UIView new];
    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[[mockSharedApplication expect] andReturn:@[view]] windows];

    UIWindow *kbWindow = nil;
    kbWindow           = [KeyboardUtils getKeyboardAccessoryWindow];

    XCTAssertNotNil(kbWindow);
    XCTAssertEqual([kbWindow class], [UIView class]);
    [mockSharedApplication stopMocking];
}

@end
