//
//  TestUtils.m
//  CernerBridgeTests
//
//  Created by Shoemake,Andrew on 4/19/19.
//  Copyright © 2019 Cerner Corporation. All rights reserved.
//

#import "TestUtils.h"

#import <XCTest/XCTest.h>

#define DEFAULT_TIMEOUT 2

@implementation TestUtils

+ (void)wait:(NSInteger)timeout {
    __unused XCTWaiterResult waitResult = [XCTWaiter waitForExpectations:@[] timeout:timeout];
}

/**
 * Wait for the default amount of time
 */
+ (void)wait {
    [TestUtils wait:DEFAULT_TIMEOUT];
}

@end
