//
//  MainViewUtilsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 10/16/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "MainViewUtils.h"
#import <XCTest/XCTest.h>

@interface MainViewUtils ()
+ (NSArray<NSString *> *)getAllLoginPages;
+ (NSArray<NSString *> *)getAllPasswordPages;
@end

@interface MainViewUtilsTest : XCTestCase
@end

@implementation MainViewUtilsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testGetPageNameFromURL {
    NSString *pageName = @"http://hostname:portNumber/TestPageName.aspx";
    XCTAssertTrue([[MainViewUtils getPageNameFromURL:pageName] isEqualToString:@"TestPageName"]);

    pageName = @"http://hostname:portNumber/";
    XCTAssertTrue([[MainViewUtils getPageNameFromURL:pageName] isEqualToString:@""]);
}

- (void)testIsStartPage {

    NSString *startPage = @"Login.aspx";
    XCTAssertTrue([MainViewUtils isStartPage:startPage]);

    startPage = @"SystemMessage.aspx";
    XCTAssertTrue([MainViewUtils isStartPage:startPage]);

    startPage = @"welcome.do";
    XCTAssertTrue([MainViewUtils isStartPage:startPage]);

    startPage = @"hhscanLoginID.do";
    XCTAssertTrue([MainViewUtils isStartPage:startPage]);

    startPage = @"logout.do";
    XCTAssertTrue([MainViewUtils isStartPage:startPage]);

    startPage = @"login.do";
    XCTAssertFalse([MainViewUtils isStartPage:startPage]);

    startPage = @"";
    XCTAssertFalse([MainViewUtils isStartPage:startPage]);
}

- (void)testIsPageTimedOut {
    NSString *page = @"";
    XCTAssertFalse([MainViewUtils isPageTimedOut:page]);

    page = @"Test String";
    XCTAssertFalse([MainViewUtils isPageTimedOut:page]);

    page = @"Page Load Timeout";
    XCTAssertTrue([MainViewUtils isPageTimedOut:page]);
}

- (void)testIsErrorPage {
    NSString *page = @"";
    XCTAssertFalse([MainViewUtils isErrorPage:page]);

    page = @"Test String";
    XCTAssertFalse([MainViewUtils isErrorPage:page]);

    page = @"Web Error Received";
    XCTAssertTrue([MainViewUtils isErrorPage:page]);
}

- (void)testContainsServerError {
    NSString *page = @"";
    XCTAssertFalse([MainViewUtils containsServerError:page]);

    page = @"Web Error Received";
    XCTAssertFalse([MainViewUtils containsServerError:page]);

    page = @"WebKitError : Web Error Received";
    XCTAssertTrue([MainViewUtils containsServerError:page]);

    page = @"Server Error";
    XCTAssertTrue([MainViewUtils containsServerError:page]);

    page = @"HTTP Status";
    XCTAssertTrue([MainViewUtils containsServerError:page]);

    page = @"HTTP Error";
    XCTAssertTrue([MainViewUtils containsServerError:page]);
}

- (void)testIsPasswordPage {
    NSString *pageUrl = @"http://testURL/NotAPasswordPage.aspx";
    XCTAssertFalse([MainViewUtils isPasswordPage:pageUrl]);

    pageUrl = @"http://testURL/ChangePassword.aspx";
    XCTAssertTrue([MainViewUtils isPasswordPage:pageUrl]);

    pageUrl = @"http://testURL/ExpiredPassword.aspx";
    XCTAssertTrue([MainViewUtils isPasswordPage:pageUrl]);
}

- (void)testGetAllLoginPages {
    NSArray<NSString *> *loginPages = [MainViewUtils getAllLoginPages];
    XCTAssertNotNil(loginPages);
    XCTAssertEqual(loginPages.count, 5);
}

- (void)testGetAllPasswordPages {
    NSArray<NSString *> *passwordPages = [MainViewUtils getAllPasswordPages];
    XCTAssertNotNil(passwordPages);
    XCTAssertEqual(passwordPages.count, 2);
}

@end
