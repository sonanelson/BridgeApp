//
//  UIViewController+TopmostPresentedViewControllerTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 12/3/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMock.h>
#import <XCTest/XCTest.h>

#import "UIViewController+TopmostPresentedViewController.h"

@interface UIViewController_TopmostPresentedViewControllerTest : XCTestCase

@end

@implementation UIViewController_TopmostPresentedViewControllerTest

- (void)setUp {
    [super setUp];
    // Put setup code here. This method is called before the invocation of each test method in the class.
}

- (void)tearDown {
    // Put teardown code here. This method is called after the invocation of each test method in the class.
    [super tearDown];
}

- (void)testTopmostPresentedViewController_NoPresentedViewController {
    UIViewController *testViewController = [[UIViewController alloc] init];

    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];

    keyWindow.rootViewController = testViewController;

    OCMockObject *mockController = [OCMockObject partialMockForObject:testViewController];
    [[[mockController expect] andReturn:NULL] presentedViewController];

    UIViewController *returnedVC = [UIViewController topmostViewController];

    CernerOCMockVerify(mockController);

    XCTAssertNotNil(returnedVC);
    XCTAssertEqual(testViewController, returnedVC);

    [mockController stopMocking];
}

- (void)testTopmostPresentedViewController_PresentedViewController_NavigationViewController {
    UIViewController *testViewController         = [[UIViewController alloc] init];
    UIViewController *presentedViewController    = [[UIViewController alloc] init];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:testViewController];

    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];

    keyWindow.rootViewController = navigationController;

    OCMockObject *mockController = [OCMockObject partialMockForObject:testViewController];
    [[[mockController expect] andReturn:presentedViewController] presentedViewController];

    OCMockObject *mockNavController = [OCMockObject partialMockForObject:navigationController];
    [[[mockNavController expect] andReturn:navigationController] presentedViewController];
    [[[mockNavController expect] andReturn:@[testViewController]] viewControllers];

    UIViewController *returnedVC = [UIViewController topmostViewController];

    CernerOCMockVerify(mockController);
    CernerOCMockVerify(mockNavController);

    XCTAssertNotNil(returnedVC);
    XCTAssertEqual(presentedViewController, returnedVC);

    [mockController stopMocking];
    [mockNavController stopMocking];
}

- (void)testTopmostPresentedViewController_PresentedViewController_TabbarController {
    UIViewController *testViewController      = [[UIViewController alloc] init];
    UIViewController *presentedViewController = [[UIViewController alloc] init];
    UITabBarController *tabbarController      = [[UITabBarController alloc] init];

    UIWindow *keyWindow = [[UIApplication sharedApplication] keyWindow];

    keyWindow.rootViewController = tabbarController;

    OCMockObject *mockController = [OCMockObject partialMockForObject:testViewController];
    [[[mockController expect] andReturn:presentedViewController] presentedViewController];

    OCMockObject *mockTabbarController = [OCMockObject partialMockForObject:tabbarController];
    [[[mockTabbarController expect] andReturn:tabbarController] presentedViewController];
    [[[mockTabbarController expect] andReturn:testViewController] selectedViewController];

    UIViewController *returnedVC = [UIViewController topmostViewController];

    CernerOCMockVerify(mockController);
    CernerOCMockVerify(mockTabbarController);

    XCTAssertNotNil(returnedVC);
    XCTAssertEqual(presentedViewController, returnedVC);

    [mockController stopMocking];
    [mockTabbarController stopMocking];
}

@end
