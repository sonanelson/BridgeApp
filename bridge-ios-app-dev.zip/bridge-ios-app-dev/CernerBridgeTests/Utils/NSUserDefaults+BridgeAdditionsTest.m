//
//  NSUserDefaults+BridgeAdditionsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/15/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "NSUserDefaults+BridgeAdditions.h"
#import <CernBaseUnitTest.h>
#import <OCMock.h>
#import <XCTest/XCTest.h>

@interface NSUserDefaults_BridgeAdditionsTest : XCTestCase

@end

@implementation NSUserDefaults_BridgeAdditionsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];

    [self removeAllDefaults];
}

- (void)removeAllDefaults {
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"WebServerName"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"WebSiteName"];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"pageTimeout"];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"enableTransfusion"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"enableSpecimen"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"enableMilk"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"enableDonorMilk"];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"enableBabyMatch"];
}

- (void)testGetPageTimeoutFromUserDefaults_NotSet {
    NSInteger pageTimeout = [NSUserDefaults getPageTimeoutFromUserDefaults];

    XCTAssertEqual(pageTimeout, 120);
}

- (void)testGetPageTimeoutFromUserDefaults_Set {
    [[NSUserDefaults standardUserDefaults] setInteger:60 forKey:@"pageTimeout"];

    NSInteger pageTimeout = [NSUserDefaults getPageTimeoutFromUserDefaults];

    XCTAssertEqual(pageTimeout, 60);
}

- (void)testAreWebServerDefaultsAlreadySet_NotSet {
    [self removeAllDefaults];

    BOOL retVal = YES;
    retVal      = [NSUserDefaults areWebServerDefaultsAlreadySet];

    XCTAssertFalse(retVal);
}

- (void)testAreWebServerDefaultsAlreadySet_Set {
    [[NSUserDefaults standardUserDefaults] setObject:@"Test_Server_Name" forKey:@"WebServerName"];
    [[NSUserDefaults standardUserDefaults] setObject:@"Test_Website_Name" forKey:@"WebSiteName"];

    BOOL retVal = NO;
    retVal      = [NSUserDefaults areWebServerDefaultsAlreadySet];

    XCTAssertTrue(retVal);
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_DefaultsAlreadySet {

    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"enableTransfusion"];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"enableSpecimen"];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"enableMilk"];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"enableDonorMilk"];
    [[NSUserDefaults standardUserDefaults] setBool:true forKey:@"enableBabyMatch"];

    NSString *testHTML = @"<title>TestTitle</title>";
    NSInteger count    = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:testHTML];

    XCTAssertEqual(count, 5);
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_DefaultsNotSet_StringNull {

    NSInteger count = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:@""];

    XCTAssertEqual(count, 0);
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_AvailableSolutionsNotFound {

    NSString *testHTML = @"<input name=\"testName\" type=\"text\" value=\"value\" text=\"\" id=\"testID\">";
    NSInteger count    = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:testHTML];

    XCTAssertEqual(count, 1); // Transfusion
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_AvailableSolutionsFound_SolutionNameEmpty {
    NSString *testHTML = @"<input name=\"availableSolutions\" type=\"text\" value=\"Trans,Spec,Milk,Baby\" text=\"\" id=\"availableSolutions\">";
    NSInteger count    = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:testHTML];

    XCTAssertEqual(count, 0);
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_AvailableSolutionsFound {
    OCMockObject *mockDefaults = [OCMockObject partialMockForObject:[NSUserDefaults standardUserDefaults]];
    [[mockDefaults expect] setBool:true forKey:@"enableTransfusion"];
    [[mockDefaults expect] setBool:true forKey:@"enableSpecimen"];
    [[mockDefaults expect] setBool:true forKey:@"enableMilk"];
    [[mockDefaults expect] setBool:true forKey:@"enableDonorMilk"];
    [[mockDefaults expect] setBool:true forKey:@"enableBabyMatch"];

    NSString *testHTML = @"<td><input name=\"availableSolutions\" type=\"text\" value=\"Trans,Spec,Milk,Baby\" id=\"availableSolutions\"></td>";
    NSInteger count    = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:testHTML];

    XCTAssertEqual(count, 5);
    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_AvailableSolutionsFound_NotCommomDefaults {
    NSString *testHTML = @"<td><input name=\"availableSolutions\" type=\"text\" value=\"solutionName\" id=\"availableSolutions\"></td>";
    NSInteger count    = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:testHTML];

    XCTAssertEqual(count, 0);
}

- (void)testSetBridgeUserDefaultsBasedOnHTML_AvailableSolutionsFound_Nil {
    OCMockObject *mockDefaults = [OCMockObject niceMockForClass:[NSUserDefaults class]];
    [[[mockDefaults stub] andReturn:@[@"testValue"]] arrayForBridgeApplicationKeys];

    NSString *testHTML = @"<td><input name=\"availableSolutions\" type=\"text\" value=\"value\" id=\"availableSolutions\"></td>";
    NSInteger count    = [NSUserDefaults setBridgeUserDefaultsBasedOnHTML:testHTML];

    XCTAssertEqual(count, 0);

    [mockDefaults stopMocking];
}

- (void)testGetSelectedApplicationIndex_Set {
    [[NSUserDefaults standardUserDefaults] setInteger:4 forKey:@"lastSelectedApp"];
    NSInteger index = [NSUserDefaults getSelectedApplicationIndex];

    XCTAssertEqual(index, 4);

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:@"lastSelectedApp"];
}

- (void)testGetSelectedApplicationIndex_NotSet {
    NSInteger index = [NSUserDefaults getSelectedApplicationIndex];

    XCTAssertEqual(index, 0);
}

@end
