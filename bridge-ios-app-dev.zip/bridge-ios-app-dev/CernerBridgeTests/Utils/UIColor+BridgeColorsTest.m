//
//  UIColor+BridgeColorsTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "UIColor+BridgeColors.h"
#import <XCTest/XCTest.h>

@interface UIColor_BridgeColorsTest : XCTestCase

@end

@implementation UIColor_BridgeColorsTest

- (void)setUp {
    [super setUp];
}

- (void)tearDown {
    [super tearDown];
}

- (void)testDefaultTextColor {
    CGFloat red, green, blue, alpha;

    UIColor *color = [UIColor defaultTextColor];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 1000) / 1000, 0.047f);
    XCTAssertEqual(floorf(green * 1000) / 1000, 0.522f);
    XCTAssertEqual(floorf(blue * 1000) / 1000, 0.741f);
    XCTAssertEqual(alpha, 1.0f);
}

- (void)testInactiveTextColor {
    CGFloat red, green, blue, alpha;

    UIColor *color = [UIColor inactiveTextColor];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 10) / 10, 0.6f);
    XCTAssertEqual(floorf(green * 10) / 10, 0.6f);
    XCTAssertEqual(floorf(blue * 10) / 10, 0.6f);
    XCTAssertEqual(alpha, 1.0f);
}

- (void)testBottomBarColor {
    CGFloat red, green, blue, alpha;

    UIColor *color = [UIColor bottomBarColor];
    [color getRed:&red green:&green blue:&blue alpha:&alpha];

    XCTAssertNotNil(color);
    XCTAssertEqual(floorf(red * 100) / 100, 0.97f);
    XCTAssertEqual(floorf(green * 100) / 100, 0.97f);
    XCTAssertEqual(floorf(blue * 100) / 100, 0.97f);
    XCTAssertEqual(alpha, 1.0f);
}

@end
