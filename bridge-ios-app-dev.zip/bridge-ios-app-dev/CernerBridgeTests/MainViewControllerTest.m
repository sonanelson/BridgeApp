//
//  MainViewControllerTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/6/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "TestUtils.h"
#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import "AlertViewUtils.h"
#import "BlockExecutionScript.h"
#import "BottomBar.h"
#import "BridgeCommonConstants.h"
#import "DropDownMenu.h"
#import "InactivityApplication.h"
#import "MainNavigationBar.h"
#import "MainViewController.h"
#import "MainViewUtils.h"
#import "MainWebView.h"
#import "NSString+Additions.h"
#import "NSUserDefaults+BridgeAdditions.h"
#import "SoundUtils.h"
#import "UIApplication+TypeAdditions.h"
#import "UIViewController+TopmostPresentedViewController.h"
#import "WebActionResponderDelegate.h"
#import "WebServerSiteViewController.h"
#import "WebServerSiteViewControllerDelegate.h"
#import "WebViewMainViewDelegate.h"

#import <CernScanningLibrary/CEABarcodeScannerConfig.h>
#import <CernScanningLibrary/CEABarcodeScannerDelegate.h>
#import <CernScanningLibrary/CEACodeCorpDriver.h>
#import <CernScanningLibrary/CEADeviceDriverDelegate.h>
#import <CernScanningLibrary/CEADeviceDriverErrors.h>
#import <CernScanningLibrary/CEAMockBarcodeScanner.h>
#import <CernScanningLibrary/CEAMockBarcodeScannerViewController.h>
#import <CernScanningLibrary/CEAScannerFactory.h>
#import <CernScanningLibrary/CernBarcode.h>
#import <CernScanningLibrary/CortexDecoderScannerViewController.h>

@interface MainViewController () <WebActionResponderDelegate,
                                  WebServerSiteViewControllerDelegate,
                                  WebViewMainViewDelegate,
                                  CEADeviceDriverDelegate,
                                  CEABarcodeScannerDelegate,
                                  CEAScannerViewPresenter>

@property (nonatomic, strong) MainNavigationBar *navigationBar;
@property (nonatomic, strong) IBOutlet BottomBar *bottomBar;
@property (nonatomic, strong) IBOutlet MainWebView *webView;
@property (nonatomic, strong) IBOutlet DropDownMenu *dropDownMenu;
@property (nonatomic, strong) NSMutableArray *queuedAlerts;
@property (nonatomic, strong) id<CEABarcodeScanner> barcodeScanner;

- (void)updateUIForPage:(NSString *)sHtml withURL:(NSString *)sUrl;
- (void)setUpNavigationBar;
- (void)setUpWebView;
- (void)alertActionResponse:(NSString *)response withServerError:(BOOL)isError;
- (NSString *)applicationURL;
- (NSString *)autoLogoutURL;
- (void)didSelectApplicationFromMenu;
- (void)processBarcode:(CernBarcode *)barcode;
- (void)setupScanning;
- (void)showInvalidBarcodeScanAlert;
- (void)presentQueuedAlertController:(UIViewController *)controller;
- (void)presentTopMostQueuedAlert;
- (void)presentAlertController:(UIAlertController *)controller;
@end

@interface MainViewControllerTest : XCTestCase
@property (nonatomic, strong) MainViewController *mainVC;
@end

@implementation MainViewControllerTest

- (void)setUp {
    [super setUp];

    MainNavigationViewController *navigationController = [MainViewController createContainingNavigationController];
    self.mainVC                                        = (MainViewController *)[navigationController topViewController];
    [self.mainVC loadView];
}

- (void)tearDown {
    [super tearDown];

    self.mainVC = nil;
}

- (void)testPerformShowAppMenuAction {
    OCMockObject *mockMainVCNavigationController = [OCMockObject partialMockForObject:self.mainVC.navigationController];
    [[mockMainVCNavigationController expect] presentViewController:OCMOCK_ANY animated:YES completion:nil];

    [self.mainVC performShowAppMenuAction];

    CernerOCMockVerify(mockMainVCNavigationController);
}

- (void)testCreateContainingNavigationController {
    UINavigationController *navigationController = [MainViewController createContainingNavigationController];

    XCTAssertNotNil(navigationController);
    XCTAssertTrue([navigationController isKindOfClass:[MainNavigationViewController class]]);
}

- (void)testCreateMainViewController {
    UIViewController *controller = [MainViewController createMainViewController];

    XCTAssertNotNil(controller);
    XCTAssertTrue([controller isKindOfClass:[MainViewController class]]);
}

- (void)testSetUpNavigationBar {
    self.mainVC.navigationBar = nil;

    [self.mainVC setUpNavigationBar];

    XCTAssertNotNil(self.mainVC.navigationBar);
    XCTAssertEqual(self.mainVC.navigationBar.actionDelegate, self.mainVC);
    XCTAssertEqual(self.mainVC.navigationBar.dropDownMenuDelegate, self.mainVC.dropDownMenu);
}

- (void)testUpdateUIForPageWithURL_EmptyHtml {

    OCMockObject *mockBottomBar = [OCMockObject partialMockForObject:self.mainVC.bottomBar];
    [[mockBottomBar reject] parseItemsWithScan:OCMOCK_ANY fromHTML:OCMOCK_ANY];

    [self.mainVC setUpNavigationBar];

    OCMockObject *mockNavigationBar = [OCMockObject partialMockForObject:self.mainVC.navigationBar];
    [[mockNavigationBar reject] parseItemsWithTitle:OCMOCK_ANY fromHTML:OCMOCK_ANY];

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.mainVC.dropDownMenu];
    [[mockDropDownMenu reject] parseItemsFromHTML:OCMOCK_ANY];

    [self.mainVC updateUIForPage:NULL withURL:NULL];

    CernerOCMockVerify(mockBottomBar);
    CernerOCMockVerify(mockNavigationBar);
    CernerOCMockVerify(mockDropDownMenu);

    [mockBottomBar stopMocking];
    [mockDropDownMenu stopMocking];
    [mockNavigationBar stopMocking];
}

- (void)testUpdateUIForPageWithURL {

    NSString *testNavBarHTML = @"<input type=\"submit\" name=\"btnAddPoc\" value=\"Test_Filter\" id=\"test_btnAddPoc_ID\">"
                               @"<input=\"submit\" name=\"backbtn\" value=\"Test_Back\" id=\"test_backbtn_ID\">"
                               @"<input type=\"submit\" name=\"lnkhome\" value=\"Test_Home\" id=\"test_lnkhome_ID\">";

    NSString *testBottomBarHTML = @"<input type=\"submit\" name=\"cancel\" value=\"Test_Cancel\" id=\"test_cancel_ID\">"
                                  @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\">"
                                  @"<input type=\"submit\" name=\"continue\" value=\"Test_Continue\" id=\"test_continue_ID\">";

    NSString *testDropDownMenuHTML = @"<a href=\"javascript:alert('Title<br>btn:button<br>Message');\" id=\"Test_lnkInfo_ID\" text=\"TestTextInfo\"></a>"
                                     @"<input type=\"submit\" name=\"lnkLogout\" value=\"Test_Logout\" id=\"Test_lnkLogout_ID\">";

    NSString *testHTML = [NSString stringWithFormat:@"<html><body>%@ \n %@ \n %@</body></html>", testNavBarHTML, testDropDownMenuHTML, testBottomBarHTML];
    NSString *testURL  = @"https://IPAddress/Package/Environment/TestPage.aspx";

    BOOL shouldScan             = NO;
    OCMockObject *mockMainUtils = [OCMockObject mockForClass:[MainViewUtils class]];
    [[[mockMainUtils stub] andReturnValue:@NO] isPasswordPage:testURL];
    [[[mockMainUtils stub] andReturn:@"TestPage"] getPageNameFromURL:testURL];

    OCMockObject *mockBottomBar = [OCMockObject partialMockForObject:self.mainVC.bottomBar];
    [[mockBottomBar expect] parseItemsWithScan:!shouldScan fromHTML:testHTML];

    [self.mainVC setUpNavigationBar];

    NSString *title                 = @"TestPage";
    OCMockObject *mockNavigationBar = [OCMockObject partialMockForObject:self.mainVC.navigationBar];
    [[mockNavigationBar expect] parseItemsWithTitle:title fromHTML:testHTML];

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.mainVC.dropDownMenu];
    [[mockDropDownMenu expect] parseItemsFromHTML:testHTML];

    [self.mainVC updateUIForPage:testHTML withURL:testURL];

    CernerOCMockVerify(mockBottomBar);
    CernerOCMockVerify(mockNavigationBar);
    CernerOCMockVerify(mockDropDownMenu);

    [mockBottomBar stopMocking];
    [mockDropDownMenu stopMocking];
    [mockNavigationBar stopMocking];
}

- (void)testViewDidLoad {
    self.mainVC.navigationBar               = nil;
    self.mainVC.webView.navigationDelegate  = nil;
    self.mainVC.bottomBar.actionDelegate    = nil;
    self.mainVC.dropDownMenu.actionDelegate = nil;

    [self.mainVC viewDidLoad];

    XCTAssertNotNil(self.mainVC.navigationBar);
    XCTAssertNotNil(self.mainVC.webView.navigationDelegate);
    XCTAssertNotNil(self.mainVC.bottomBar.actionDelegate);
    XCTAssertNotNil(self.mainVC.dropDownMenu.actionDelegate);
}

- (void)testSetUpWebView_DelegateNil {
    self.mainVC.webView.webViewNavigationBarDelegate = nil;
    self.mainVC.webView.webViewMainViewDelegate      = nil;
    [self.mainVC setUpNavigationBar];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView expect] initialize];
    [[[mockWebView expect] andReturnValue:@YES] checkWebSettingsExist];
    [[mockWebView expect] loadURL:OCMOCK_ANY shouldSetLastURL:YES];

    [self.mainVC setUpWebView];

    XCTAssertNotNil(self.mainVC.webView.webViewNavigationBarDelegate);
    XCTAssertNotNil(self.mainVC.webView.webViewMainViewDelegate);

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}
/*
- (void)testSetUpWebView_DelegateNotNil {
    [self.mainVC setUpNavigationBar];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:self.mainVC.navigationBar] webViewNavigationBarDelegate];
    [[[mockWebView stub] andReturn:self.mainVC] webViewMainViewDelegate];
    [[[mockWebView stub] andReturn:self.mainVC.webView] navigationDelegate];

    [[mockWebView reject] initialize];
    [[[mockWebView reject] andReturnValue:@YES] checkWebSettingsExist];
    [[mockWebView reject] loadURL:OCMOCK_ANY shouldSetLastURL:YES];

    [self.mainVC setUpWebView];

    XCTAssertNotNil(self.mainVC.webView.webViewNavigationBarDelegate);
    XCTAssertNotNil(self.mainVC.webView.webViewMainViewDelegate);

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}
*/
- (void)testViewWillAppear {
    self.mainVC.navigationBar               = nil;
    self.mainVC.webView.navigationDelegate  = nil;
    self.mainVC.bottomBar.actionDelegate    = nil;
    self.mainVC.dropDownMenu.actionDelegate = nil;

    [self.mainVC viewWillAppear:YES];

    XCTAssertNotNil(self.mainVC.navigationBar);
    XCTAssertNotNil(self.mainVC.bottomBar.actionDelegate);
    XCTAssertNotNil(self.mainVC.dropDownMenu.actionDelegate);
}

- (void)testLoadLoginPageBasedOnWebSettings {
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView expect] loadURL:OCMOCK_ANY shouldSetLastURL:YES];

    [self.mainVC loadLoginPageBasedOnWebSettings];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

- (void)testAutoLogout {

    OCMockObject *mockSharedApplication = [OCMockObject partialMockForObject:[UIApplication sharedApplication]];
    [[UIApplication inactivityApplication] disableIdleTimer];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView expect] loadURL:OCMOCK_ANY shouldSetLastURL:YES];

    [self.mainVC autoLogout];

    CernerOCMockVerify(mockSharedApplication);
    CernerOCMockVerify(mockWebView);

    [mockSharedApplication stopMocking];
    [mockWebView stopMocking];
}

- (void)testDisplayWebSettingsErrorPage {

    UINavigationController *navigationController  = [UINavigationController new];
    OCMockObject *mockWebServerSiteViewController = [OCMockObject mockForClass:[WebServerSiteViewController class]];
    [[[mockWebServerSiteViewController expect] andReturn:navigationController] createContainingNavigationController];

    WebServerSiteViewController *controller = [WebServerSiteViewController new];
    OCMockObject *mockNavigationController  = [OCMockObject partialMockForObject:navigationController];
    [[[mockNavigationController expect] andReturn:controller] topViewController];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf expect] presentViewController:navigationController animated:NO completion:nil];

    __block void (^checkBlock)(void);
    OCMockObject *mockMainQueue = [OCMockObject partialMockForObject:[NSOperationQueue mainQueue]];
    [[mockMainQueue expect] addOperationWithBlock:[OCMArg checkWithBlock:^BOOL(id block) {
                                checkBlock = block;
                                return YES;
                            }]];

    [self.mainVC displayWebSettingsErrorPage];

    CernerOCMockSafeBlockExecute(checkBlock, checkBlock());

    CernerOCMockVerify(mockNavigationController);
    CernerOCMockVerify(mockWebServerSiteViewController);
    CernerOCMockVerify(mockSelf);

    [mockWebServerSiteViewController stopMocking];
    [mockNavigationController stopMocking];
    [mockSelf stopMocking];
}

- (void)testAlertActionResponseWithServerError_isError {

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf expect] displayWebSettingsErrorPage];

    [self.mainVC alertActionResponse:NULL withServerError:YES];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testAlertActionResponseWithServerError_isResponseEmpty {

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf reject] displayWebSettingsErrorPage];
    [[mockSelf reject] performActionBasedOnJavascript:OCMOCK_ANY];

    [self.mainVC alertActionResponse:NULL withServerError:NO];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testAlertActionResponseWithServerError_isResponseURL {

    NSString *response = @"https://test:port/pgaeName.aspx";
    NSURL *url         = [NSURL URLWithString:response];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf reject] displayWebSettingsErrorPage];
    [[mockSelf reject] performActionBasedOnJavascript:OCMOCK_ANY];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView expect] loadURL:url shouldSetLastURL:NO];

    [self.mainVC alertActionResponse:response withServerError:NO];

    CernerOCMockVerify(mockSelf);
    CernerOCMockVerify(mockWebView);

    [mockSelf stopMocking];
    [mockWebView stopMocking];
}

- (void)testAlertActionResponseWithServerError_isResponseJavaScript {

    NSString *response = @"<a id=\"alertbox\" class=\"errorText\" href='javascript:alert(\"Alert<br>btn:OK<br>Error Text.\");'></a>";

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf reject] displayWebSettingsErrorPage];
    [[mockSelf expect] performActionBasedOnJavascript:response];

    [self.mainVC alertActionResponse:response withServerError:NO];

    CernerOCMockVerify(mockSelf);

    [mockSelf stopMocking];
}

- (void)testPresentAlertControllerWithActionTitlesAndInfo_OneActionClicked {
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"TestTitle" message:@"TestMessage" preferredStyle:UIAlertControllerStyleAlert];

    NSString *response = @"Test Response";

    BOOL isError = YES;

    NSArray *actions = @[@"ButtonTitle"];

    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];
    OCMockObject *mockSelf                  = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf expect] alertActionResponse:response withServerError:isError];
    [[mockTopmostViewController expect] presentViewController:controller animated:YES completion:OCMOCK_ANY];

    __block void (^action)(UIAlertAction *action);
    OCMockObject *mockAlertActionClass = [OCMockObject niceMockForClass:[UIAlertAction class]];
    [[[mockAlertActionClass expect] andForwardToRealObject] actionWithTitle:@"ButtonTitle"
                                                                      style:UIAlertActionStyleCancel
                                                                    handler:(void (^__nullable)(UIAlertAction *action))[OCMArg checkWithBlock:^BOOL(id obj) {
                                                                        action = [obj copy];
                                                                        return YES;
                                                                    }]];

    NSDictionary *info = @{@"alert_OkResponse_key": response, @"alert_ServerErrorResponse_key": [NSNumber numberWithBool:isError]};
    [self.mainVC presentAlertController:controller withActionTitles:actions andInfo:info];

    XCTAssertTrue(controller.actions.count == 1);

    CernerOCMockSafeBlockExecute(action, action(nil));

    CernerOCMockVerify(mockAlertActionClass);
    CernerOCMockVerify(mockSelf);
    CernerOCMockVerify(mockTopmostViewController);

    [mockAlertActionClass stopMocking];
    [mockTopmostViewController stopMocking];
    [mockSelf stopMocking];
}

- (void)testPresentAlertControllerWithActionsAndInfo_OneActionClickedResponseNull {
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"TestTitle" message:@"TestMessage" preferredStyle:UIAlertControllerStyleAlert];
    NSArray *actions              = @[@"ButtonTitle"];
    BOOL isError                  = YES;

    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];
    OCMockObject *mockSelf                  = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf reject] alertActionResponse:OCMOCK_ANY withServerError:isError];
    [[mockTopmostViewController expect] presentViewController:controller animated:YES completion:nil];

    __block void (^action)(UIAlertAction *action);
    OCMockObject *mockAlertActionClass = [OCMockObject niceMockForClass:[UIAlertAction class]];
    [[[mockAlertActionClass expect] andForwardToRealObject] actionWithTitle:@"ButtonTitle"
                                                                      style:UIAlertActionStyleCancel
                                                                    handler:(void (^__nullable)(UIAlertAction *action))[OCMArg checkWithBlock:^BOOL(id obj) {
                                                                        action = [obj copy];
                                                                        return YES;
                                                                    }]];

    NSDictionary *info = @{@"alert_ServerErrorResponse_key": [NSNumber numberWithBool:isError]};
    [self.mainVC presentAlertController:controller withActionTitles:actions andInfo:info];

    XCTAssertTrue(controller.actions.count == 1);

    CernerOCMockSafeBlockExecute(action, action(nil));

    CernerOCMockVerify(mockAlertActionClass);
    CernerOCMockVerify(mockSelf);
    CernerOCMockVerify(mockTopmostViewController);

    [mockAlertActionClass stopMocking];
    [mockTopmostViewController stopMocking];
    [mockSelf stopMocking];
}

- (void)testPresentAlertControllerWithActionsAndInfo_TwoActions_SecondButtonClicked {
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"TestTitle" message:@"TestMessage" preferredStyle:UIAlertControllerStyleAlert];

    NSArray *actions = @[@"ButtonTitle", @"SecondButtonTitle"];

    NSString *response = @"Test Response";

    BOOL isError = YES;

    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];
    OCMockObject *mockSelf                  = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf expect] alertActionResponse:response withServerError:isError];
    [[mockTopmostViewController expect] presentViewController:controller animated:YES completion:nil];

    __block void (^action)(UIAlertAction *action);
    OCMockObject *mockAlertActionClass = [OCMockObject niceMockForClass:[UIAlertAction class]];
    [[[mockAlertActionClass expect] andForwardToRealObject] actionWithTitle:@"SecondButtonTitle"
                                                                      style:UIAlertActionStyleDefault
                                                                    handler:(void (^__nullable)(UIAlertAction *action))[OCMArg checkWithBlock:^BOOL(id obj) {
                                                                        action = [obj copy];
                                                                        return YES;
                                                                    }]];

    [[[mockAlertActionClass expect] andForwardToRealObject] actionWithTitle:@"ButtonTitle"
                                                                      style:UIAlertActionStyleCancel
                                                                    handler:(void (^__nullable)(UIAlertAction *action))[OCMArg isNotNil]];

    NSDictionary *info = @{@"alert_cancelResponse_key": response, @"alert_ServerErrorResponse_key": [NSNumber numberWithBool:isError]};
    [self.mainVC presentAlertController:controller withActionTitles:actions andInfo:info];

    XCTAssertTrue(controller.actions.count == 2);

    CernerOCMockSafeBlockExecute(action, action(nil));

    CernerOCMockVerify(mockAlertActionClass);
    CernerOCMockVerify(mockSelf);
    CernerOCMockVerify(mockTopmostViewController);

    [mockAlertActionClass stopMocking];
    [mockTopmostViewController stopMocking];
    [mockSelf stopMocking];
}

- (void)testPresentAlertControllerWithActionsAndInfo_TwoAction_SecondClickedResponseNull {
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"TestTitle" message:@"TestMessage" preferredStyle:UIAlertControllerStyleAlert];
    NSArray *actions              = @[@"ButtonTitle", @"SecondButtonTitle"];
    BOOL isError                  = YES;

    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];
    [[mockTopmostViewController expect] presentViewController:controller animated:YES completion:nil];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf reject] alertActionResponse:OCMOCK_ANY withServerError:isError];

    __block void (^action)(UIAlertAction *action);
    OCMockObject *mockAlertActionClass = [OCMockObject niceMockForClass:[UIAlertAction class]];
    [[[mockAlertActionClass expect] andForwardToRealObject] actionWithTitle:@"SecondButtonTitle"
                                                                      style:UIAlertActionStyleDefault
                                                                    handler:(void (^__nullable)(UIAlertAction *action))[OCMArg checkWithBlock:^BOOL(id obj) {
                                                                        action = [obj copy];
                                                                        return YES;
                                                                    }]];

    NSDictionary *info = @{@"alert_ServerErrorResponse_key": [NSNumber numberWithBool:isError]};
    [self.mainVC presentAlertController:controller withActionTitles:actions andInfo:info];

    XCTAssertTrue(controller.actions.count == 2);

    CernerOCMockSafeBlockExecute(action, action(nil));

    CernerOCMockVerify(mockAlertActionClass);
    CernerOCMockVerify(mockSelf);
    CernerOCMockVerify(mockTopmostViewController);

    [mockAlertActionClass stopMocking];
    [mockTopmostViewController stopMocking];
    [mockSelf stopMocking];
}

- (void)testPresentAlertControllerWithActionsAndInfo_QueuedAlerts {
    UIAlertController *controller = [UIAlertController alertControllerWithTitle:@"TestTitle" message:@"TestMessage" preferredStyle:UIAlertControllerStyleAlert];
    NSArray *actions              = @[@"ButtonTitle"];
    BOOL isError                  = YES;

    self.mainVC.queuedAlerts = [NSMutableArray arrayWithCapacity:1];

    OCMockObject *mockTopmostViewController = [OCMockObject niceMockForClass:[UIViewController class]];
    [[[mockTopmostViewController stub] andReturn:[CortexDecoderScannerViewController new]] topmostViewController];

    OCMockObject *mockSelf = [OCMockObject partialMockForObject:self.mainVC];
    [[mockSelf reject] alertActionResponse:OCMOCK_ANY withServerError:isError];
    [[mockTopmostViewController reject] presentViewController:controller animated:YES completion:nil];

    __block void (^action)(UIAlertAction *action);
    OCMockObject *mockAlertActionClass = [OCMockObject niceMockForClass:[UIAlertAction class]];
    [[[mockAlertActionClass expect] andForwardToRealObject] actionWithTitle:@"ButtonTitle"
                                                                      style:UIAlertActionStyleCancel
                                                                    handler:(void (^__nullable)(UIAlertAction *action))[OCMArg checkWithBlock:^BOOL(id obj) {
                                                                        action = [obj copy];
                                                                        return YES;
                                                                    }]];

    NSDictionary *info = @{@"alert_ServerErrorResponse_key": [NSNumber numberWithBool:isError]};
    [self.mainVC presentAlertController:controller withActionTitles:actions andInfo:info];

    XCTAssertTrue(controller.actions.count == 1);
    XCTAssertTrue(self.mainVC.queuedAlerts.count == 1);

    CernerOCMockSafeBlockExecute(action, action(nil));

    CernerOCMockVerify(mockAlertActionClass);
    CernerOCMockVerify(mockSelf);
    CernerOCMockVerify(mockTopmostViewController);

    [mockAlertActionClass stopMocking];
    [mockTopmostViewController stopMocking];
    [mockSelf stopMocking];
}

- (void)testPerformActionBasedOnJavascript_EmptyJavascript {
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView reject] evaluateJavaScript:OCMOCK_ANY completionHandler:nil];

    [self.mainVC performActionBasedOnJavascript:@""];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

- (void)testPerformActionBasedOnJavascript {
    NSString *javascript = @"<a id=\"alertbox\" class=\"errorText\" href='javascript:alert(\"Alert<br>btn:OK<br>Error Text.\");'></a>";

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView expect] evaluateJavaScript:javascript completionHandler:nil];

    [self.mainVC performActionBasedOnJavascript:javascript];

    CernerOCMockVerify(mockWebView);

    [mockWebView stopMocking];
}

- (void)testApplicationURL_webSettingsNotSet {
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView expect] andReturnValue:@NO] checkWebSettingsExist];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[mockDefaults reject] getSelectedApplicationIndex];

    NSString *retURL = @"testURL";
    retURL           = [self.mainVC applicationURL];

    XCTAssertTrue([retURL isEqualToString:@""]);

    CernerOCMockVerify(mockWebView);
    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
    [mockDefaults stopMocking];
}

- (void)testApplicationURL_DefaultLoginPage {
    [[NSUserDefaults standardUserDefaults] setObject:@"testserver" forKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] setObject:@"testsite" forKey:kDefaultsKey_WebSiteName];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView expect] andReturnValue:@YES] checkWebSettingsExist];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:@0] getSelectedApplicationIndex]; // Transfusion

    NSString *retURL = @"";
    retURL           = [self.mainVC applicationURL];

    NSString *timeZone    = [NSTimeZone localTimeZone].name;
    NSString *expectedURL = [NSString stringWithFormat:@"http://testserver/testsite/HandHeld/Login.aspx?TimeZone=%@", timeZone];
    XCTAssertTrue([retURL isEqualToString:expectedURL]);

    CernerOCMockVerify(mockWebView);
    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
    [mockDefaults stopMocking];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebSiteName];
}

- (void)testApplicationURL_BabyMatchLoginPage {
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"enableSSL"];
    [[NSUserDefaults standardUserDefaults] setObject:@"testserver" forKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] setObject:@"testsite" forKey:kDefaultsKey_WebSiteName];

    NSString *timeZone        = [NSTimeZone localTimeZone].name;
    NSString *expectedURL     = [NSString stringWithFormat:@"http://testserver/testsite/HandHeld/BabyMatch/Login.aspx?TimeZone=%@", timeZone];
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView expect] andReturnValue:@YES] checkWebSettingsExist];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(3)] getSelectedApplicationIndex]; // BabyMatch

    NSString *retURL = @"";
    retURL           = [self.mainVC applicationURL];

    XCTAssertTrue([retURL isEqualToString:expectedURL]);

    CernerOCMockVerify(mockWebView);
    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
    [mockDefaults stopMocking];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebSiteName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_EnableSSL];
}

- (void)testApplicationURL_DonorMilkLoginPage {
    [[NSUserDefaults standardUserDefaults] setBool:NO forKey:@"enableSSL"];
    [[NSUserDefaults standardUserDefaults] setObject:@"testserver" forKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] setObject:@"testsite" forKey:kDefaultsKey_WebSiteName];

    NSString *timeZone        = [NSTimeZone localTimeZone].name;
    NSString *expectedURL     = [NSString stringWithFormat:@"http://testserver/testsite/HandHeld/DonorMilk/Login.aspx?TimeZone=%@", timeZone];
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView expect] andReturnValue:@YES] checkWebSettingsExist];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(4)] getSelectedApplicationIndex]; // Donor milk

    NSString *retURL = @"";
    retURL           = [self.mainVC applicationURL];

    XCTAssertTrue([retURL isEqualToString:expectedURL]);

    CernerOCMockVerify(mockWebView);
    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
    [mockDefaults stopMocking];

    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebServerName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_WebSiteName];
    [[NSUserDefaults standardUserDefaults] removeObjectForKey:kDefaultsKey_EnableSSL];
}

- (void)testAutoLogoutURL {
    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(4)] getSelectedApplicationIndex];

    NSString *URL             = @"http://testserver/testsite/HandHeld/DonorMilk/Login.aspx";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:URL] applicationURL];

    NSString *retVal = @"";
    retVal           = [self.mainVC autoLogoutURL];

    XCTAssertTrue([retVal containsString:kLogoutPage_Default]);
    XCTAssertFalse([retVal containsString:kLoginPage_Default]);

    CernerOCMockVerify(mockDefaults);

    [mockWebView stopMocking];
    [mockDefaults stopMocking];
}

- (void)testAutoLogoutURL_NULL {
    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(4)] getSelectedApplicationIndex];

    NSString *URL             = @"http://testserver/testsite/HandHeld/DonorMilk/test.aspx";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:URL] applicationURL];

    NSString *retVal = @"";
    retVal           = [self.mainVC autoLogoutURL];

    XCTAssertFalse([retVal containsString:kLogoutPage_Default]);
    XCTAssertTrue([retVal isEqualToString:URL]);

    CernerOCMockVerify(mockDefaults);

    [mockWebView stopMocking];
    [mockDefaults stopMocking];
}

- (void)testAutoLogoutURL_MedAdmin {
    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(5)] getSelectedApplicationIndex];

    NSString *URL             = @"https://testserver/testsite/HandHeld/hhwelcome.do";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:URL] applicationURL];

    NSString *retVal = @"";
    retVal           = [self.mainVC autoLogoutURL];

    XCTAssertTrue([retVal containsString:kLogoutPage_MedAdmin]);
    XCTAssertFalse([retVal containsString:kLoginPage_MedAdmin]);

    CernerOCMockVerify(mockDefaults);

    [mockWebView stopMocking];
    [mockDefaults stopMocking];
}

- (void)testProcessBarcode_alertShowing {
    NSString *URL             = @"https://testserver/testsite/HandHeld/Login.aspx";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:[NSURL URLWithString:URL]] URL];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[mockDefaults expect] getSelectedApplicationIndex];

    NSString *barcodeString = @"";
    CernBarcode *barcode    = [[CernBarcode alloc] initWithData:[barcodeString dataUsingEncoding:NSUTF8StringEncoding] symbology:CEABarcodeSymbologyQR];

    [self.mainVC processBarcode:barcode];

    CernerOCMockVerify(mockDefaults);

    [mockDefaults stopMocking];
    [mockWebView stopMocking];
}

- (void)testProcessBarcode_Medadmin {
    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC expect] performActionBasedOnJavascript:OCMOCK_ANY];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(5)] getSelectedApplicationIndex];

    NSString *barcodeString = @"";
    CernBarcode *barcode    = [[CernBarcode alloc] initWithData:[barcodeString dataUsingEncoding:NSUTF8StringEncoding] symbology:CEABarcodeSymbologyQR];

    [self.mainVC processBarcode:barcode];

    CernerOCMockVerify(mockDefaults);
    CernerOCMockVerify(mockMainVC);

    [mockDefaults stopMocking];
    [mockMainVC stopMocking];
}

- (void)testProcessBarcode_ParamsNotFound {
    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC reject] performActionBasedOnJavascript:OCMOCK_ANY];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(0)] getSelectedApplicationIndex];

    NSString *barcodeString = @"testBarcode";
    CernBarcode *barcode    = [[CernBarcode alloc] initWithData:[barcodeString dataUsingEncoding:NSUTF8StringEncoding] symbology:CEABarcodeSymbologyQR];

    NSString *URL             = @"https://testserver/testsite/HandHeld/Login.aspx";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:[NSURL URLWithString:URL]] URL];
    NSURL *loadedURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@?barcode=%@", URL, barcodeString]];
    [[mockWebView expect] loadURL:loadedURL shouldSetLastURL:FALSE];

    [self.mainVC processBarcode:barcode];

    CernerOCMockVerify(mockDefaults);
    CernerOCMockVerify(mockMainVC);
    CernerOCMockVerify(mockWebView);

    [mockDefaults stopMocking];
    [mockMainVC stopMocking];
    [mockWebView stopMocking];
}

- (void)testProcessBarcode_ParamsDoNotContainBarcode {
    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC reject] performActionBasedOnJavascript:OCMOCK_ANY];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(0)] getSelectedApplicationIndex];

    NSString *barcodeString = @"testBarcode";
    CernBarcode *barcode    = [[CernBarcode alloc] initWithData:[barcodeString dataUsingEncoding:NSUTF8StringEncoding] symbology:CEABarcodeSymbologyQR];

    NSString *URL             = @"https://testserver/testsite/HandHeld/Login.aspx?parameters";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:[NSURL URLWithString:URL]] URL];
    NSURL *loadedURL = [NSURL URLWithString:[NSString stringWithFormat:@"%@&barcode=%@", URL, barcodeString]];
    [[mockWebView expect] loadURL:loadedURL shouldSetLastURL:FALSE];

    [self.mainVC processBarcode:barcode];

    CernerOCMockVerify(mockDefaults);
    CernerOCMockVerify(mockMainVC);
    CernerOCMockVerify(mockWebView);

    [mockDefaults stopMocking];
    [mockMainVC stopMocking];
    [mockWebView stopMocking];
}

- (void)testProcessBarcode {
    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC reject] performActionBasedOnJavascript:OCMOCK_ANY];

    OCMockObject *mockDefaults = [OCMockObject mockForClass:[NSUserDefaults class]];
    [[[mockDefaults expect] andReturnValue:OCMOCK_VALUE(0)] getSelectedApplicationIndex];

    NSString *barcodeString = @"testBarcode";
    CernBarcode *barcode    = [[CernBarcode alloc] initWithData:[barcodeString dataUsingEncoding:NSUTF8StringEncoding] symbology:CEABarcodeSymbologyQR];

    NSString *URL             = @"https://testserver/testsite/HandHeld/Login.aspx?barcode=barcode";
    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[[mockWebView stub] andReturn:[NSURL URLWithString:URL]] URL];

    NSURL *loadedURL = [NSURL URLWithString:[URL stringByReplacingOccurrencesOfString:@"barcode" withString:@"testBarcode"]];
    [[mockWebView expect] loadURL:loadedURL shouldSetLastURL:FALSE];

    [self.mainVC processBarcode:barcode];

    CernerOCMockVerify(mockDefaults);
    CernerOCMockVerify(mockMainVC);
    CernerOCMockVerify(mockWebView);

    [mockDefaults stopMocking];
    [mockMainVC stopMocking];
    [mockWebView stopMocking];
}

- (void)testDidSelectApplicationFromMenu {
    NSString *URLString = @"https://testserver/testsite/HandHeld/Login.aspx?barcode=barcode";
    NSURL *url          = [NSURL URLWithString:URLString];

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[[mockMainVC expect] andReturn:URLString] applicationURL];

    OCMockObject *mockWebView = [OCMockObject partialMockForObject:self.mainVC.webView];
    [[mockWebView expect] loadURL:url shouldSetLastURL:YES];

    [self.mainVC didSelectApplicationFromMenu];

    CernerOCMockVerify(mockMainVC);
    CernerOCMockVerify(mockWebView);

    [mockMainVC stopMocking];
    [mockWebView stopMocking];
}

/**
 * Verify the scanner is set up correctly with the correct config
 */
- (void)testSetupScanning {
    OCMockObject *mockCEACodeCorpDriver = [OCMockObject niceMockForClass:[CEACodeCorpDriver class]];
    [[mockCEACodeCorpDriver expect] setActivationKey:OCMOCK_ANY];

    // Since this is the simulator we'll have to use the mock barcode scanner
    OCMockObject *mockScannerClass = [OCMockObject niceMockForClass:[CEAMockBarcodeScanner class]];
    [[mockScannerClass expect] connectWithConfiguration:(CEABarcodeScannerConfig *)[OCMArg checkWithBlock:^BOOL(id obj) {
                                   CEABarcodeScannerConfig *config = (CEABarcodeScannerConfig *)obj;
                                   XCTAssertEqual(config.scannerMode, CEAScannerModeTarget);
                                   XCTAssertFalse(config.continuousMode);
                                   XCTAssertTrue(config.fullScreen);
                                   XCTAssertEqual(config.cameraType, CEACameraBackFacking);
                                   return YES;
                               }]
                                     withDriverDelegate:self.mainVC];

    CernerOCMockSafeExecute([self.mainVC setupScanning]);

    CernerOCMockVerify(mockCEACodeCorpDriver);
    CernerOCMockVerify(mockScannerClass);

    [mockCEACodeCorpDriver stopMocking];
    [mockScannerClass stopMocking];
}

/**
 * Verify that when the scanner is successfully connected it is installed and the delegates are set up
 */
- (void)testDriverDidConnect {
    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];

    OCMockObject *mockScannerFactory = [OCMockObject partialMockForObject:[CEAScannerFactory getSharedInstance]];
    [[mockScannerFactory expect] installScanner:mockBarcodeScanner];

    self.mainVC.barcodeScanner = mockBarcodeScanner;

    CernerOCMockSafeExecute([self.mainVC driverDidConnect:mockBarcodeScanner]);

    CernerOCMockVerify(mockScannerFactory);

    XCTAssertEqual(mockBarcodeScanner.barcodeScannerDelegate, self.mainVC);
    XCTAssertEqual(mockBarcodeScanner.scannerViewPresenter, self.mainVC);

    [mockScannerFactory stopMocking];
}

/**
 * Verify no exception for nil
 */
- (void)testDriverConnectFailedWithError {
    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner connectFailedWithError:nil]);
}

/**
 * Verify alert for license invalid
 */
- (void)testDriverConnectFailedWithError_LicenseInvalid {
    NSError *error = [NSError errorWithDomain:CEADeviceDriverDomain code:CEALicenseInvalid userInfo:nil];

    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner connectFailedWithError:error]);

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];

    [[mockMainVC expect] presentAlertController:[OCMArg checkWithBlock:^BOOL(UIAlertController *controller) {
                             XCTAssertEqual(controller.actions.count, 1);
                             XCTAssertEqualObjects(controller.actions[0].title, @"Dismiss");
                             return YES;
                         }]];

    [mockMainVC stopMocking];
}

/**
 * Verify alert for license invalid
 */
- (void)testDriverConnectFailedWithError_NetworkUnavailable {
    NSError *error = [NSError errorWithDomain:CEADeviceDriverDomain code:CEANetworkNotAvailable userInfo:nil];

    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner connectFailedWithError:error]);

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];

    [[mockMainVC expect] presentAlertController:[OCMArg checkWithBlock:^BOOL(UIAlertController *controller) {
                             XCTAssertEqual(controller.actions.count, 1);
                             XCTAssertEqualObjects(controller.actions[0].title, @"Dismiss");
                             return YES;
                         }]];

    [mockMainVC stopMocking];
}

/**
 * Verify alert for license server not available
 */
- (void)testDriverConnectFailedWithError_ServerNotAvailable {
    NSError *error = [NSError errorWithDomain:CEADeviceDriverDomain code:CEALicenseServerNotAvailable userInfo:nil];

    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner connectFailedWithError:error]);

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];

    [[mockMainVC expect] presentAlertController:[OCMArg checkWithBlock:^BOOL(UIAlertController *controller) {
                             XCTAssertEqual(controller.actions.count, 1);
                             XCTAssertEqualObjects(controller.actions[0].title, @"Dismiss");
                             return YES;
                         }]];

    [mockMainVC stopMocking];
}

/**
 * Verify alert for license expired
 */
- (void)testDriverConnectFailedWithError_LicenseExpired {
    NSError *error = [NSError errorWithDomain:CEADeviceDriverDomain code:CEALicenseExpired userInfo:nil];

    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner connectFailedWithError:error]);

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];

    [[mockMainVC expect] presentAlertController:[OCMArg checkWithBlock:^BOOL(UIAlertController *controller) {
                             XCTAssertEqual(controller.actions.count, 1);
                             XCTAssertEqualObjects(controller.actions[0].title, @"Dismiss");
                             return YES;
                         }]];

    [mockMainVC stopMocking];
}

/**
 * Verify alert for license mismatch
 */
- (void)testDriverConnectFailedWithError_LicenseMistmatch {
    NSError *error = [NSError errorWithDomain:CEADeviceDriverDomain code:CEALicenseMismatch userInfo:nil];

    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner connectFailedWithError:error]);

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];

    [[mockMainVC expect] presentAlertController:[OCMArg checkWithBlock:^BOOL(UIAlertController *controller) {
                             XCTAssertEqual(controller.actions.count, 1);
                             XCTAssertEqualObjects(controller.actions[0].title, @"Dismiss");
                             return YES;
                         }]];

    [mockMainVC stopMocking];
}

/**
 * Verify no exception for now
 */
- (void)testDriverDisconnectFailedWithError {
    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driver:mockBarcodeScanner disconnectFailedWithError:nil]);
}

/**
 * Verify no exception for now
 */
- (void)testDriverDidDisconnect {
    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];
    XCTAssertNoThrow([self.mainVC driverDidDisconnect:mockBarcodeScanner]);
}

/**
 * Verify the topmost view controller presents the scanner view
 */
- (void)testBarcodeScannerPresentScannerView {
    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];

    CEAMockBarcodeScannerViewController *mockScannerView = [[CEAMockBarcodeScannerViewController alloc] init];
    [[mockTopmostViewController expect] presentViewController:mockScannerView animated:YES completion:nil];

    CernerOCMockSafeExecute([self.mainVC barcodeScanner:nil presentScannerView:mockScannerView]);

    CernerOCMockVerify(mockTopmostViewController);

    [mockTopmostViewController stopMocking];
}

/**
 * Verify the scanner view is dismissed
 */
- (void)testBarcodeScannerDismissScannerView_NoQueuedAlerts {
    self.mainVC.queuedAlerts = [NSMutableArray arrayWithArray:@[]];

    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];
    [[mockTopmostViewController reject] presentViewController:OCMOCK_ANY animated:OCMOCK_ANY completion:nil];

    CEAMockBarcodeScannerViewController *mockScannerView = [[CEAMockBarcodeScannerViewController alloc] init];
    OCMockObject *mockMockScannerViewController          = [OCMockObject partialMockForObject:mockScannerView];

    __block void (^completion)(void);
    [[mockMockScannerViewController expect] dismissViewControllerAnimated:YES
                                                               completion:[OCMArg checkWithBlock:^BOOL(void (^block)(void)) {
                                                                   completion = block;
                                                                   return YES;
                                                               }]];

    CernerOCMockSafeExecute([self.mainVC barcodeScanner:nil dismissScannerView:mockScannerView]);

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion());

    CernerOCMockVerify(mockMockScannerViewController);

    [mockMockScannerViewController stopMocking];
    [mockTopmostViewController stopMocking];
}

/**
 * Verify the scanner view is dismissed
 */
- (void)testBarcodeScannerDismissScannerView_QueuedAlerts {
    UIAlertController *newAlertController = [UIAlertController new];
    self.mainVC.queuedAlerts              = [NSMutableArray arrayWithArray:@[newAlertController]];

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC expect] presentQueuedAlertController:newAlertController];

    CEAMockBarcodeScannerViewController *mockScannerView = [[CEAMockBarcodeScannerViewController alloc] init];
    OCMockObject *mockMockScannerViewController          = [OCMockObject partialMockForObject:mockScannerView];

    __block void (^completion)(void);
    [[mockMockScannerViewController expect] dismissViewControllerAnimated:YES
                                                               completion:[OCMArg checkWithBlock:^BOOL(void (^block)(void)) {
                                                                   completion = block;
                                                                   return YES;
                                                               }]];

    CernerOCMockSafeExecute([self.mainVC barcodeScanner:nil dismissScannerView:mockScannerView]);

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion());

    CernerOCMockVerify(mockMockScannerViewController);

    [mockMockScannerViewController stopMocking];
    [mockMainVC stopMocking];
}

- (void)testPresentQueuedAlertController {
    UIAlertController *newAlertController = [UIAlertController new];

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC expect] presentTopMostQueuedAlert];

    __block void (^completion)(void);
    OCMockObject *mockTopmostViewController = [OCMockObject partialMockForObject:[UIViewController topmostViewController]];
    [[mockTopmostViewController expect] presentViewController:newAlertController
                                                     animated:YES
                                                   completion:[OCMArg checkWithBlock:^BOOL(void (^block)(void)) {
                                                       completion = block;

                                                       return YES;
                                                   }]];

    [self.mainVC presentQueuedAlertController:newAlertController];

    [TestUtils wait];

    CernerOCMockSafeBlockExecute(completion, completion());

    CernerOCMockVerify(mockMainVC);
    CernerOCMockVerify(mockTopmostViewController);

    [mockTopmostViewController stopMocking];
    [mockMainVC stopMocking];
}

/**
 * Verify the mainVC processes the scanned barcode
 */
- (void)testBarcodeScannerDidScanBarcodes {
    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];

    NSString *barcodeString = @"";
    CernBarcode *barcode    = [[CernBarcode alloc] initWithData:[barcodeString dataUsingEncoding:NSUTF8StringEncoding] symbology:CEABarcodeSymbologyQR];

    [[mockMainVC expect] processBarcode:barcode];

    CernerOCMockSafeExecute([self.mainVC barcodeScanner:nil didScanBarcodes:@[barcode]]);

    CernerOCMockVerify(mockMainVC);

    [mockMainVC stopMocking];
}

- (void)testShowInvalidBarcodeScanAlert {
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"title" message:@"MESSAGE" preferredStyle:UIAlertControllerStyleAlert];
    OCMockObject *mockAlertUtils       = [OCMockObject mockForClass:[AlertViewUtils class]];
    [[[mockAlertUtils expect] andReturn:alertController] alertWithErrorType:kErrorAlertType_InvalidBarcode andMessage:NULL];

    OCMockObject *mockMainVC = [OCMockObject partialMockForObject:self.mainVC];
    [[mockMainVC expect] presentAlertController:alertController withActionTitles:OCMOCK_ANY andInfo:nil];

    [self.mainVC showInvalidBarcodeScanAlert];
    CernerOCMockVerify(mockMainVC);

    [mockMainVC stopMocking];
}

- (void)testKeyboardWillChangeFrame {
    CGFloat duration       = 0.25;
    NSDictionary *userInfo = @{UIKeyboardAnimationDurationUserInfoKey: [NSNumber numberWithFloat:duration],
                               UIKeyboardAnimationCurveUserInfoKey: [NSNumber numberWithInteger:7]};
    OCMockObject *mockView = [OCMockObject mockForClass:[UIView class]];
    [[mockView expect] animateWithDuration:duration
                                     delay:0.0
                                   options:7 << 16
                                animations:OCMOCK_ANY
                                completion:nil];

    [[NSNotificationCenter defaultCenter] postNotificationName:UIKeyboardWillChangeFrameNotification
                                                        object:nil
                                                      userInfo:userInfo];

    CernerOCMockVerify(mockView);
    [mockView stopMocking];
}

@end
