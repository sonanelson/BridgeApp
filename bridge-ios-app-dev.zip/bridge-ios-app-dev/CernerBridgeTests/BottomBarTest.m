//
//  BottomBarTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 11/2/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

#import "BottomBar.h"
#import "BridgeCommonConstants.h"
#import "HTMLParser+XPathHelper.h"
#import "ScannerInitializer.h"
#import "UIColor+BridgeColors.h"
#import "WebActionResponderDelegate.h"

#import <CernScanningLibrary/CEABarcodeScanner.h>
#import <CernScanningLibrary/CEAMockBarcodeScanner.h>
#import <CernScanningLibrary/CEAScannerFactory.h>

@interface BottomBar ()
typedef NS_ENUM(NSInteger, BottomBarItems) {
    kBottomBarItem_Left  = 0,
    kBottomBarItem_Scan  = 1,
    kBottomBarItem_Right = 2
};

// IBOutlets
@property (nonatomic, strong) IBOutlet UIButton *leftButton;
@property (nonatomic, strong) IBOutlet UIButton *scanButton;
@property (nonatomic, strong) IBOutlet UIButton *rightButton;

// Strings
@property (nonatomic, strong) NSString *leftButtonID;
@property (nonatomic, strong) NSString *rightButtonID;
@property (nonatomic, strong) NSString *leftButtonText;
@property (nonatomic, strong) NSString *rightButtonText;
@property (nonatomic, strong) NSString *scanButtonText;

// BOOLs
@property (nonatomic, assign) BOOL shouldEnableScanTab;
@property (nonatomic, assign) BOOL showPatientsActive;
@property (nonatomic, assign) BOOL showMenuActive;
@property (nonatomic, assign) BOOL showContinue;
@property (nonatomic, assign) BOOL showCancel;

- (void)makeVisibleInWebpage;
- (void)adjustVisibilityOfRightButton;
- (void)adjustVisibilityOfLeftButton;
- (IBAction)performActionBasedOnButtonClick:(UIButton *)sender;
- (UIColor *)titleColorForButton:(UIButton *)button;
- (BOOL)shouldHideBottomBar;
- (BOOL)isMainBar;
- (BOOL)shouldEnableLeftButton;
- (BOOL)shouldEnableRightButton;
- (void)resetToDefaults;
- (void)setUIAttributesForButtonsWithScan:(BOOL)shouldScan;
- (void)setButtonAttributesFromHTML:(HTMLElement *)element;
- (void)setButton:(UIButton *)button withImage:(NSString *)imageName title:(NSString *)title enabled:(BOOL)enabled tag:(BottomBarItems)tag;
@end

@interface BottomBarTest : XCTestCase <ScannerInitializer>
@property (nonatomic, strong) BottomBar *bottomBar;
@property (nonatomic) BOOL scanningSetup;
@end

@implementation BottomBarTest

- (void)setUp {
    [super setUp];

    self.bottomBar     = [[BottomBar alloc] init];
    self.scanningSetup = NO;
}

- (void)tearDown {
    [super tearDown];

    self.bottomBar = nil;
}

- (void)testAwakeFromNib {
    [self.bottomBar awakeFromNib];

    XCTAssertFalse(self.bottomBar.showContinue);
    XCTAssertFalse(self.bottomBar.showCancel);
    XCTAssertFalse(self.bottomBar.showPatientsActive);
    XCTAssertFalse(self.bottomBar.showMenuActive);
}

- (void)testResetToDefaults {
    self.bottomBar.showContinue       = true;
    self.bottomBar.showCancel         = true;
    self.bottomBar.showPatientsActive = true;
    self.bottomBar.showMenuActive     = true;

    [self.bottomBar resetToDefaults];

    XCTAssertFalse(self.bottomBar.showContinue);
    XCTAssertFalse(self.bottomBar.showCancel);
    XCTAssertFalse(self.bottomBar.showPatientsActive);
    XCTAssertFalse(self.bottomBar.showMenuActive);
}

- (void)testIsMainBar {
    self.bottomBar.showCancel   = true;
    self.bottomBar.showContinue = false;

    XCTAssertFalse([self.bottomBar isMainBar]);

    self.bottomBar.showCancel   = false;
    self.bottomBar.showContinue = true;

    XCTAssertFalse([self.bottomBar isMainBar]);

    self.bottomBar.showCancel   = true;
    self.bottomBar.showContinue = true;

    XCTAssertFalse([self.bottomBar isMainBar]);

    self.bottomBar.showCancel   = false;
    self.bottomBar.showContinue = false;

    XCTAssertTrue([self.bottomBar isMainBar]);
}

- (void)testShouldEnableLeftButton {

    self.bottomBar.showCancel   = true;
    self.bottomBar.showContinue = true;

    XCTAssertTrue([self.bottomBar shouldEnableLeftButton]);

    self.bottomBar.showCancel         = false;
    self.bottomBar.showContinue       = false;
    self.bottomBar.showPatientsActive = true;

    XCTAssertTrue([self.bottomBar shouldEnableLeftButton]);

    self.bottomBar.showCancel         = false;
    self.bottomBar.showContinue       = false;
    self.bottomBar.showPatientsActive = false;

    XCTAssertFalse([self.bottomBar shouldEnableLeftButton]);
}

- (void)testShouldEnableRightButton {

    self.bottomBar.showCancel   = true;
    self.bottomBar.showContinue = true;

    XCTAssertTrue([self.bottomBar shouldEnableRightButton]);

    self.bottomBar.showCancel     = false;
    self.bottomBar.showContinue   = false;
    self.bottomBar.showMenuActive = true;

    XCTAssertTrue([self.bottomBar shouldEnableRightButton]);

    self.bottomBar.showCancel     = false;
    self.bottomBar.showContinue   = false;
    self.bottomBar.showMenuActive = false;

    XCTAssertFalse([self.bottomBar shouldEnableRightButton]);
}

- (void)testShouldHideBottomBar {

    self.bottomBar.showContinue        = false;
    self.bottomBar.showCancel          = false;
    self.bottomBar.showMenuActive      = false;
    self.bottomBar.showPatientsActive  = false;
    self.bottomBar.shouldEnableScanTab = false;

    self.bottomBar.hidden = false;
    [self.bottomBar shouldHideBottomBar];
    XCTAssertTrue(self.bottomBar.hidden);

    self.bottomBar.showContinue = true;

    self.bottomBar.hidden = true;
    [self.bottomBar shouldHideBottomBar];
    XCTAssertFalse(self.bottomBar.hidden);

    self.bottomBar.hidden = true;
    [self.bottomBar shouldHideBottomBar];
    XCTAssertFalse(self.bottomBar.hidden);
}

- (void)testSetTabAttributesFromHTML {
    // Patient
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_lnkchangepatient", @"type": @"submit", @"name": @"test_Name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Text"];

    self.bottomBar.showCancel         = false;
    self.bottomBar.showContinue       = false;
    self.bottomBar.showPatientsActive = false;
    self.bottomBar.leftButtonText     = @"sample text";

    [self.bottomBar setButtonAttributesFromHTML:element];

    XCTAssertTrue(self.bottomBar.showPatientsActive);
    XCTAssertTrue([self.bottomBar.leftButtonText isEqualToString:element.text]);

    // Home
    properties = @{@"value": @"Value", @"id": @"test_lnkhome", @"type": @"submit", @"name": @"test_Name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Text"];

    self.bottomBar.showMenuActive  = false;
    self.bottomBar.rightButtonText = @"sample text";

    [self.bottomBar setButtonAttributesFromHTML:element];

    XCTAssertTrue(self.bottomBar.showMenuActive);
    XCTAssertTrue([self.bottomBar.rightButtonText isEqualToString:element.text]);

    // cancel
    properties = @{@"value": @"Value", @"id": @"test_cancel", @"type": @"submit", @"name": @"test_Name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Text"];

    [self.bottomBar setButtonAttributesFromHTML:element];

    XCTAssertTrue(self.bottomBar.showCancel);
    XCTAssertTrue([self.bottomBar.leftButtonID isEqualToString:element.elementID]);
    XCTAssertTrue([self.bottomBar.leftButtonText isEqualToString:element.text]);

    // Continue
    properties = @{@"value": @"Value", @"id": @"test_continue", @"type": @"submit", @"name": @"test_Name"};
    element    = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Text"];

    [self.bottomBar setButtonAttributesFromHTML:element];

    XCTAssertTrue(self.bottomBar.showContinue);
    XCTAssertTrue([self.bottomBar.rightButtonID isEqualToString:element.elementID]);
    XCTAssertTrue([self.bottomBar.rightButtonText isEqualToString:element.text]);
}

/**
 * Verify scanning is setup after it is detected a valid Bridge server is in use
 */
- (void)testSetTabAttributesFromHTML_TypeScan {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"scan", @"type": @"submit", @"name": @"test_Name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Text"];

    self.bottomBar.scannerInitializer = self;
    [self.bottomBar setButtonAttributesFromHTML:element];

    XCTAssertTrue(self.bottomBar.shouldEnableScanTab);
    XCTAssertTrue(self.scanningSetup);
}

- (void)testPerformActionBasedOnButtonClick_LeftButton {

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;
    self.bottomBar.leftButtonID   = @"TestLeftID";
    self.bottomBar.rightButtonID  = @"TestRightID";

    // Left tab
    NSString *leftExpectedValue = [NSString stringWithFormat:kClickScript, self.bottomBar.leftButtonID];
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:leftExpectedValue]);
                         }]];

    UIButton *button = [[UIButton alloc] init];
    button.tag       = kBottomBarItem_Left;
    [self.bottomBar performActionBasedOnButtonClick:button];
    [mockDelegate stopMocking];
}

- (void)testPerformActionBasedOnButtonClick_RightTab {

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;
    self.bottomBar.rightButtonID  = @"TestRightID";

    NSString *expectedValue = [NSString stringWithFormat:kClickScript, self.bottomBar.rightButtonID];
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:expectedValue]);
                         }]];

    UIButton *button = [[UIButton alloc] init];
    button.tag       = kBottomBarItem_Right;
    [self.bottomBar performActionBasedOnButtonClick:button];
    [mockDelegate stopMocking];
}

/**
 * Verify the scanner view is presented
 */
- (void)testPerformActionBasedOnButtonClick_ScanTab {
    OCMockObject *mockScannerFactory          = [OCMockObject partialMockForObject:[CEAScannerFactory getSharedInstance]];
    CEAMockBarcodeScanner *mockBarcodeScanner = [[CEAMockBarcodeScanner alloc] init];

    OCMockObject *mockMockBarcodeScanner = [OCMockObject partialMockForObject:mockBarcodeScanner];
    [[mockMockBarcodeScanner expect] presentView];

    [[[mockScannerFactory stub] andReturn:mockBarcodeScanner] getInstalledBarcodeScanner];

    UIButton *button = [[UIButton alloc] init];
    button.tag       = kBottomBarItem_Scan;
    CernerOCMockSafeExecute([self.bottomBar performActionBasedOnButtonClick:button]);

    CernerOCMockVerify(mockMockBarcodeScanner);

    [mockMockBarcodeScanner stopMocking];
    [mockScannerFactory stopMocking];
}

/**
 * Verify if the scanner is not set up, it is attempted to be set up
 */
- (void)testPerformActionBasedOnButtonClick_ScanTab_NotInitialized {
    [[CEAScannerFactory getSharedInstance] installScanner:nil];

    self.bottomBar.scannerInitializer = self;

    UIButton *button = [[UIButton alloc] init];
    button.tag       = kBottomBarItem_Scan;
    CernerOCMockSafeExecute([self.bottomBar performActionBasedOnButtonClick:button]);

    XCTAssertTrue(self.scanningSetup);
}

- (void)testMakeVisibleInWebpage {
    self.bottomBar.leftButtonID  = @"Test_Left_ID";
    self.bottomBar.rightButtonID = @"Test_Right_ID";

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;
    [[mockDelegate expect] performActionBasedOnJavascript:OCMOCK_ANY];
    [[mockDelegate expect] performActionBasedOnJavascript:OCMOCK_ANY];

    [self.bottomBar makeVisibleInWebpage];
    CernerOCMockVerify(mockDelegate);

    [mockDelegate stopMocking];
}

- (void)testAdjustVisibilityOfLeftButton_Empty {
    self.bottomBar.leftButtonID = @"";

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;
    [[mockDelegate reject] performActionBasedOnJavascript:OCMOCK_ANY];

    [self.bottomBar adjustVisibilityOfLeftButton];
    CernerOCMockVerify(mockDelegate);

    [mockDelegate stopMocking];
}

- (void)testAdjustVisibilityOfLeftButton_WithID {
    self.bottomBar.leftButtonID = @"Test_LeftTab_ID";

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;

    NSString *expectedValue = [NSString stringWithFormat:kVisibilityScript, self.bottomBar.leftButtonID];
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:expectedValue]);
                         }]];

    [self.bottomBar adjustVisibilityOfLeftButton];
    [mockDelegate stopMocking];
}

- (void)testAdjustVisibilityOfRightButton_Empty {
    self.bottomBar.rightButtonID = @"";

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;
    [[mockDelegate reject] performActionBasedOnJavascript:OCMOCK_ANY];

    [self.bottomBar adjustVisibilityOfRightButton];
    CernerOCMockVerify(mockDelegate);

    [mockDelegate stopMocking];
}

- (void)testAdjustVisibilityOfRightButton_WithID {
    self.bottomBar.rightButtonID = @"Test_RightTab_ID";

    id mockDelegate               = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.bottomBar.actionDelegate = mockDelegate;

    NSString *expectedValue = [NSString stringWithFormat:kVisibilityScript, self.bottomBar.rightButtonID];
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:expectedValue]);
                         }]];

    [self.bottomBar adjustVisibilityOfRightButton];
    [mockDelegate stopMocking];
}

- (void)testSetButtonWithImageTitleEnabledTag {

    UIButton *button = [[UIButton alloc] init];
    [self.bottomBar setButton:button withImage:@"cancelIcon" title:@"Test_Title" enabled:YES tag:kBottomBarItem_Left];

    XCTAssertTrue(button.enabled);
    XCTAssertEqual(button.tag, kBottomBarItem_Left);
    XCTAssertNotNil(button.imageView.image);
    XCTAssertTrue([button.titleLabel.text isEqualToString:@"Test_Title"]);
    XCTAssertNotEqual(button.imageEdgeInsets.top, 0.0f);
    XCTAssertNotEqual(button.titleEdgeInsets.top, 0.0f);
}

- (void)testSetUIAttributesForButtonsWithScan_NotMainBar {

    self.bottomBar.showCancel      = true;
    self.bottomBar.showContinue    = true;
    self.bottomBar.leftButtonText  = @"Test_Left_Button_Text";
    self.bottomBar.rightButtonText = @"Test_Left_Button_Text";

    OCMockObject *mockBottomBar = [OCMockObject partialMockForObject:self.bottomBar];
    self.bottomBar.leftButton   = [UIButton new];
    self.bottomBar.rightButton  = [UIButton new];
    self.bottomBar.scanButton   = [UIButton new];
    [[mockBottomBar expect] makeVisibleInWebpage];
    [[mockBottomBar expect] setButton:self.bottomBar.leftButton withImage:@"cancelIcon" title:self.bottomBar.leftButtonText enabled:true tag:kBottomBarItem_Left];
    [[mockBottomBar expect] setButton:self.bottomBar.rightButton withImage:@"confirmIcon" title:self.bottomBar.rightButtonText enabled:true tag:kBottomBarItem_Right];
    [[mockBottomBar reject] setButton:self.bottomBar.scanButton withImage:OCMOCK_ANY title:OCMOCK_ANY enabled:OCMOCK_ANY tag:kBottomBarItem_Scan];

    [self.bottomBar setUIAttributesForButtonsWithScan:false];
    CernerOCMockVerify(mockBottomBar);
    [mockBottomBar stopMocking];
}

- (void)testSetUIAttributesForButtonsWithScan_Inactive {
    self.bottomBar.leftButtonText     = @"Test_Left_Button_Text";
    self.bottomBar.rightButtonText    = @"Test_Left_Button_Text";
    self.bottomBar.showCancel         = false;
    self.bottomBar.showContinue       = false;
    self.bottomBar.showPatientsActive = false;
    self.bottomBar.showMenuActive     = false;

    OCMockObject *mockBottomBar = [OCMockObject partialMockForObject:self.bottomBar];
    [[[mockBottomBar stub] andReturnValue:@NO] shouldHideBottomBar];

    self.bottomBar.leftButton  = [UIButton new];
    self.bottomBar.rightButton = [UIButton new];
    self.bottomBar.scanButton  = [UIButton new];
    [[mockBottomBar expect] makeVisibleInWebpage];
    [[mockBottomBar expect] setButton:self.bottomBar.leftButton withImage:@"patientIcon" title:self.bottomBar.leftButtonText enabled:false tag:kBottomBarItem_Left];
    [[mockBottomBar expect] setButton:self.bottomBar.rightButton withImage:@"menuListIcon" title:self.bottomBar.rightButtonText enabled:false tag:kBottomBarItem_Right];
    [[mockBottomBar reject] setButton:self.bottomBar.scanButton withImage:OCMOCK_ANY title:OCMOCK_ANY enabled:OCMOCK_ANY tag:kBottomBarItem_Scan];

    [self.bottomBar setUIAttributesForButtonsWithScan:false];
    CernerOCMockVerify(mockBottomBar);
    [mockBottomBar stopMocking];
}

- (void)testSetUIAttributesForButtonsWithScan_ActiveAndScanEnabled {
    self.bottomBar.leftButtonText      = @"Test_Left_Button_Text";
    self.bottomBar.rightButtonText     = @"Test_Left_Button_Text";
    self.bottomBar.scanButtonText      = @"Test_Scan_Button_Text";
    self.bottomBar.showCancel          = false;
    self.bottomBar.showContinue        = false;
    self.bottomBar.showPatientsActive  = true;
    self.bottomBar.showMenuActive      = true;
    self.bottomBar.shouldEnableScanTab = true;

    OCMockObject *mockBottomBar = [OCMockObject partialMockForObject:self.bottomBar];
    [[[mockBottomBar stub] andReturnValue:@NO] shouldHideBottomBar];

    self.bottomBar.leftButton  = [UIButton new];
    self.bottomBar.rightButton = [UIButton new];
    self.bottomBar.scanButton  = [UIButton new];
    [[mockBottomBar expect] makeVisibleInWebpage];
    [[mockBottomBar expect] setButton:self.bottomBar.leftButton withImage:@"patientIcon" title:self.bottomBar.leftButtonText enabled:true tag:kBottomBarItem_Left];
    [[mockBottomBar expect] setButton:self.bottomBar.rightButton withImage:@"menuListIcon" title:self.bottomBar.rightButtonText enabled:true tag:kBottomBarItem_Right];
    [[mockBottomBar expect] setButton:self.bottomBar.scanButton withImage:@"scanIcon" title:self.bottomBar.scanButtonText enabled:true tag:kBottomBarItem_Scan];

    [self.bottomBar setUIAttributesForButtonsWithScan:true];
    CernerOCMockVerify(mockBottomBar);

    [mockBottomBar stopMocking];
}

- (void)testParseItemsWithScanFromHTML {

    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];

    NSString *testHTML = @"<input type=\"submit\" name=\"cancel\" value=\"Test_Cancel\" id=\"test_cancel_ID\">"
                         @"<input=\"submit\" name=\"scan\" value=\"Test_Scan\" id=\"test_scan_ID\">"
                         @"<input type=\"submit\" name=\"continue\" value=\"Test_Continue\" id=\"test_continue_ID\">";

    OCMockObject *mockBottomBar = [OCMockObject partialMockForObject:self.bottomBar];
    [[mockBottomBar expect] resetToDefaults];
    [[mockBottomBar expect] setUIAttributesForButtonsWithScan:false];
    [[mockBottomBar expect] setButtonAttributesFromHTML:element];

    OCMockObject *mockParser = [OCMockObject mockForClass:[HTMLParser class]];
    [[[mockParser stub] andReturn:@[element]] getBottomBarElementsFromHTML:testHTML];

    [self.bottomBar parseItemsWithScan:false fromHTML:testHTML];

    CernerOCMockVerify(mockBottomBar);
    [mockParser stopMocking];
    [mockBottomBar stopMocking];
}

- (void)setupScanning {
    self.scanningSetup = YES;
}

@end
