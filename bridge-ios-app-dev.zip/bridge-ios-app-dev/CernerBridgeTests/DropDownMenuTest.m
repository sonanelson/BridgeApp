//
//  DropDownMenuTest.m
//  CernerBridgeTests
//
//  Created by Gore,Divya on 10/12/18.
//  Copyright © 2018 Cerner Corporation. All rights reserved.
//

#import "DropDownMenu.h"
#import "HTMLParser+XPathHelper.h"
#import "MainViewController.h"
#import <CernBaseUnitTest.h>
#import <OCMockObject.h>
#import <XCTest/XCTest.h>

@interface DropDownMenu () <UITableViewDelegate, UITableViewDataSource>
@property (nonatomic, assign) BOOL canLogout;
@property (nonatomic, strong) NSString *helpTitle;
@property (nonatomic, strong) NSString *helpID;
@property (nonatomic, strong) NSString *logoutTitle;
@property (nonatomic, strong) NSString *logoutID;
- (void)addTapGesture;
- (void)handleTap:(UITapGestureRecognizer *)tap;
- (void)resetCellAttributesToDefaults;
- (void)setCellAttributesFromHTML:(HTMLElement *)element;
@end

@interface DropDownMenuTest : XCTestCase

@property (nonatomic, strong) DropDownMenu *dropDownMenu;
@end

@implementation DropDownMenuTest

- (void)setUp {
    [super setUp];

    self.dropDownMenu = [[DropDownMenu alloc] init];
}

- (void)tearDown {
    [super tearDown];

    self.dropDownMenu = nil;
}

- (void)testAwakeFromNib {

    [self.dropDownMenu awakeFromNib];

    XCTAssertTrue(self.dropDownMenu.hidden);
    XCTAssertFalse(self.dropDownMenu.canLogout);
    XCTAssertTrue([self.dropDownMenu.gestureRecognizers.lastObject isKindOfClass:[UITapGestureRecognizer class]]);
}

- (void)testShouldHideTrueAndReloadTrue {

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu expect] reloadData];

    CernerOCMockSafeExecute([self.dropDownMenu shouldHide:true andReload:true]);

    XCTAssertTrue(self.dropDownMenu.hidden);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testShouldHideFalseAndReloadFalse {

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu reject] reloadData];

    CernerOCMockSafeExecute([self.dropDownMenu shouldHide:false andReload:false]);

    XCTAssertFalse(self.dropDownMenu.hidden);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testSetLogoutCellAttributesFromHTML {
    NSDictionary *properties = @{@"value": @"Logout1", @"id": @"test_lnkLogout", @"type": @"submit", @"name": @"test_Logout"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Logout1"];

    [self.dropDownMenu setCellAttributesFromHTML:element];
    XCTAssertTrue(self.dropDownMenu.canLogout);
    XCTAssertEqual(self.dropDownMenu.logoutID, element.elementID);
    XCTAssertEqual(self.dropDownMenu.logoutTitle, element.text);
}

- (void)testSetLogoutCellAttributesFromHTML_NotLogoutElement {
    self.dropDownMenu.canLogout   = false;
    self.dropDownMenu.logoutID    = @"";
    self.dropDownMenu.logoutTitle = @"";

    NSDictionary *properties = @{@"value": @"Logout1", @"id": @"test_SomeOtherElement", @"type": @"submit", @"name": @"test_Logout"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Logout1"];

    [self.dropDownMenu setCellAttributesFromHTML:element];
    XCTAssertFalse(self.dropDownMenu.canLogout);
    XCTAssertEqual(self.dropDownMenu.logoutID, @"");
    XCTAssertEqual(self.dropDownMenu.logoutTitle, @"");
}

- (void)testSetHelpCellAttributesFromHTML {
    NSDictionary *properties = @{@"value": @"Help1", @"id": @"test_Help", @"type": @"submit", @"name": @"test_Help", @"text": @"Help1"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"Help1"];

    [self.dropDownMenu setCellAttributesFromHTML:element];
    XCTAssertEqual(self.dropDownMenu.helpID, element.elementID);
    XCTAssertEqual(self.dropDownMenu.helpTitle, element.properties[@"text"]);
}

- (void)testSetHelpCellAttributesFromHTML_ElementNull {
    self.dropDownMenu.helpID    = @"";
    self.dropDownMenu.helpTitle = @"";

    [self.dropDownMenu setCellAttributesFromHTML:NULL];
    XCTAssertEqual(self.dropDownMenu.helpID, @"");
    XCTAssertEqual(self.dropDownMenu.helpTitle, @"");
}

- (void)testResetCellAttributesToDefaults {

    [self.dropDownMenu resetCellAttributesToDefaults];

    XCTAssertFalse(self.dropDownMenu.canLogout);
    XCTAssertTrue([self.dropDownMenu.helpID isEqualToString:@""]);
    XCTAssertTrue([self.dropDownMenu.helpTitle isEqualToString:@"Help"]);
    XCTAssertTrue([self.dropDownMenu.logoutID isEqualToString:@""]);
    XCTAssertTrue([self.dropDownMenu.logoutTitle isEqualToString:@"Logout"]);
}

- (void)testNumberOfItemsInMenu {
    self.dropDownMenu.canLogout = true;
    self.dropDownMenu.helpID    = @"HelpID";
    NSInteger numberOfItems     = [self.dropDownMenu numberOfItemsInMenu];

    XCTAssertEqual(numberOfItems, 2);

    self.dropDownMenu.canLogout = false;
    numberOfItems               = [self.dropDownMenu numberOfItemsInMenu];
    XCTAssertEqual(numberOfItems, 1);

    self.dropDownMenu.helpID = @"";
    numberOfItems            = [self.dropDownMenu numberOfItemsInMenu];
    XCTAssertEqual(numberOfItems, 0);

    self.dropDownMenu.canLogout = false;
    self.dropDownMenu.helpID    = @"HelpID";
    numberOfItems               = [self.dropDownMenu numberOfItemsInMenu];
    XCTAssertEqual(numberOfItems, 1);
}

- (void)testHandleTapWithDropDowntableHidden {

    self.dropDownMenu.hidden           = true;
    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] init];

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu reject] shouldHide:OCMOCK_ANY andReload:OCMOCK_ANY];
    [[mockDropDownMenu reject] tableView:OCMOCK_ANY didSelectRowAtIndexPath:OCMOCK_ANY];

    CernerOCMockSafeExecute([self.dropDownMenu handleTap:tapGesture]);
    CernerOCMockVerify(mockDropDownMenu);
    [mockDropDownMenu stopMocking];
}

- (void)testHandleTapWithTapOutsideRows {
    self.dropDownMenu.hidden       = false;
    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu expect] shouldHide:true andReload:false];
    [[mockDropDownMenu reject] tableView:OCMOCK_ANY didSelectRowAtIndexPath:OCMOCK_ANY];

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] init];
    CernerOCMockSafeExecute([self.dropDownMenu handleTap:tapGesture]);
    CernerOCMockVerify(mockDropDownMenu);
    [mockDropDownMenu stopMocking];
}

- (void)testHandleTapWithTapOnExistingRow {
    self.dropDownMenu.hidden       = false;
    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    NSIndexPath *dummyIndexPath    = [NSIndexPath indexPathForRow:0 inSection:0];
    [[[mockDropDownMenu stub] andReturn:dummyIndexPath] indexPathForRowAtPoint:CGPointZero];
    [[mockDropDownMenu reject] shouldHide:OCMOCK_ANY andReload:OCMOCK_ANY];
    [[mockDropDownMenu expect] tableView:OCMOCK_ANY didSelectRowAtIndexPath:dummyIndexPath];

    UITapGestureRecognizer *tapGesture = [[UITapGestureRecognizer alloc] init];
    CernerOCMockSafeExecute([self.dropDownMenu handleTap:tapGesture]);
    CernerOCMockVerify(mockDropDownMenu);
    [mockDropDownMenu stopMocking];
}

- (void)testDropdownMenuNumberOfSectionsInTableview {
    NSInteger numberOfSections = [self.dropDownMenu numberOfSectionsInTableView:self.dropDownMenu];
    XCTAssertEqual(numberOfSections, 1);
}

- (void)testDropDownMenuNumberOfRowsInSection {
    self.dropDownMenu.canLogout = true;
    self.dropDownMenu.helpID    = @"TestHelpID";
    NSInteger numberOfRows      = [self.dropDownMenu tableView:self.dropDownMenu numberOfRowsInSection:0];
    XCTAssertEqual(numberOfRows, 2);

    self.dropDownMenu.canLogout = false;
    numberOfRows                = [self.dropDownMenu tableView:self.dropDownMenu numberOfRowsInSection:0];
    XCTAssertEqual(numberOfRows, 1);
}

- (void)testDropDownMenuCellForRowAtIndexPath_Help {
    NSIndexPath *dummyIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    self.dropDownMenu.helpTitle = @"TestHelpTitle";

    UITableViewCell *mockedCell    = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reuseIdentifier"];
    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[[mockDropDownMenu stub] andReturn:mockedCell] dequeueReusableCellWithIdentifier:OCMOCK_ANY forIndexPath:dummyIndexPath];

    UITableViewCell *cell = [self.dropDownMenu tableView:self.dropDownMenu cellForRowAtIndexPath:dummyIndexPath];
    XCTAssertTrue([cell.textLabel.text isEqualToString:self.dropDownMenu.helpTitle]);

    [mockDropDownMenu stopMocking];
}

- (void)testDropDownMenuCellForRowAtIndexPath_Logout {
    NSIndexPath *dummyIndexPath   = [NSIndexPath indexPathForRow:1 inSection:0];
    self.dropDownMenu.logoutTitle = @"TestLogoutTitle";

    UITableViewCell *mockedCell    = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"reuseIdentifier"];
    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[[mockDropDownMenu stub] andReturn:mockedCell] dequeueReusableCellWithIdentifier:OCMOCK_ANY forIndexPath:dummyIndexPath];

    UITableViewCell *cell = [self.dropDownMenu tableView:self.dropDownMenu cellForRowAtIndexPath:dummyIndexPath];
    XCTAssertTrue([cell.textLabel.text isEqualToString:self.dropDownMenu.logoutTitle]);

    [mockDropDownMenu stopMocking];
}

- (void)testDropDownMenuDidSelectRow_Help {

    self.dropDownMenu.helpID = @"TestHelpID";
    NSString *expectedValue  = [NSString stringWithFormat:@"window.location=document.getElementById('%@').href;", self.dropDownMenu.helpID];

    id mockDelegate                  = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.dropDownMenu.actionDelegate = mockDelegate;
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:expectedValue]);
                         }]];

    NSIndexPath *dummyIndexPath = [NSIndexPath indexPathForRow:0 inSection:0];
    CernerOCMockSafeExecute([self.dropDownMenu tableView:self.dropDownMenu didSelectRowAtIndexPath:dummyIndexPath]);

    XCTAssertTrue(self.dropDownMenu.hidden);
    [mockDelegate stopMocking];
}

- (void)testDropDownMenuDidSelectRowLogout_WithLogoutID {
    self.dropDownMenu.logoutID = @"TestLogoutID";
    NSString *expectedValue    = [NSString stringWithFormat:@"document.getElementById('%@').click();", self.dropDownMenu.logoutID];

    id mockDelegate                  = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.dropDownMenu.actionDelegate = mockDelegate;
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:expectedValue]);
                         }]];

    NSIndexPath *dummyIndexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    CernerOCMockSafeExecute([self.dropDownMenu tableView:self.dropDownMenu didSelectRowAtIndexPath:dummyIndexPath]);

    XCTAssertTrue(self.dropDownMenu.hidden);
    [mockDelegate stopMocking];
}

- (void)testDropDownMenuDidSelectRowLogout_WithoutLogoutID {
    self.dropDownMenu.logoutID       = @"";
    self.dropDownMenu.applicationURL = @"TestApplicationURL";
    NSString *expectedValue          = [NSString stringWithFormat:@"confirm('%@<br><br>Logout<br>Are you sure you want to logout of your account?');", self.dropDownMenu.applicationURL];

    id mockDelegate                  = [OCMockObject niceMockForProtocol:@protocol(WebActionResponderDelegate)];
    self.dropDownMenu.actionDelegate = mockDelegate;
    [[mockDelegate stub] performActionBasedOnJavascript:[OCMArg checkWithBlock:^BOOL(NSString *value) {
                             XCTAssertTrue([value isEqualToString:expectedValue]);
                         }]];

    NSIndexPath *dummyIndexPath = [NSIndexPath indexPathForRow:1 inSection:0];
    CernerOCMockSafeExecute([self.dropDownMenu tableView:self.dropDownMenu didSelectRowAtIndexPath:dummyIndexPath]);

    XCTAssertTrue(self.dropDownMenu.hidden);
    [mockDelegate stopMocking];
}

- (void)testPerformActionBasedOnNavigationBarButtonClick_LeftHidden {
    self.dropDownMenu.hidden = YES;

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu reject] shouldHide:true andReload:false];

    CernerOCMockSafeExecute([self.dropDownMenu performActionBasedOnNavigationBarButtonClick:kNavBarButton_Left]);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testPerformActionBasedOnNavigationBarButtonClick_LeftNotHidden {
    self.dropDownMenu.hidden = NO;

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu expect] shouldHide:true andReload:false];

    CernerOCMockSafeExecute([self.dropDownMenu performActionBasedOnNavigationBarButtonClick:kNavBarButton_Left]);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testPerformActionBasedOnNavigationBarButtonClick_MenuNotHidden {
    self.dropDownMenu.hidden = NO;

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu expect] shouldHide:true andReload:false];

    CernerOCMockSafeExecute([self.dropDownMenu performActionBasedOnNavigationBarButtonClick:kNavBarButton_Menu]);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testPerformActionBasedOnNavigationBarButtonClick_RightZeroNumberOfItemsInMenu {
    self.dropDownMenu.hidden    = NO;
    self.dropDownMenu.canLogout = NO;
    self.dropDownMenu.helpID    = @"";

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];

    [[mockDropDownMenu reject] shouldHide:true andReload:false];

    CernerOCMockSafeExecute([self.dropDownMenu performActionBasedOnNavigationBarButtonClick:kNavBarButton_Right]);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testPerformActionBasedOnNavigationBarButtonClick_RightNumberOfItemsInMenuGreaterThanZero {
    self.dropDownMenu.hidden    = YES;
    self.dropDownMenu.canLogout = YES;
    self.dropDownMenu.helpID    = @"TestHelpID";

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];

    [[mockDropDownMenu expect] shouldHide:NO andReload:YES];

    CernerOCMockSafeExecute([self.dropDownMenu performActionBasedOnNavigationBarButtonClick:kNavBarButton_Right]);
    CernerOCMockVerify(mockDropDownMenu);

    [mockDropDownMenu stopMocking];
}

- (void)testParseItemsFromHTML {
    NSDictionary *properties = @{@"value": @"Value", @"id": @"test_ID", @"name": @"name"};
    HTMLElement *element     = [[HTMLElement alloc] initWithElementType:@"input" properties:properties text:@"text"];

    NSString *testHTML = @"<a href=\"javascript:alert('Title<br>btn:button<br>Message');\" id=\"Test_lnkInfo_ID\" text=\"TestTextInfo\"></a>"
                         @"<input type=\"submit\" name=\"lnkLogout\" value=\"Test_Logout\" id=\"Test_lnkLogout_ID\">";

    OCMockObject *mockDropDownMenu = [OCMockObject partialMockForObject:self.dropDownMenu];
    [[mockDropDownMenu expect] resetCellAttributesToDefaults];
    [[mockDropDownMenu expect] setCellAttributesFromHTML:element];

    OCMockObject *mockParser = [OCMockObject mockForClass:[HTMLParser class]];
    [[[mockParser stub] andReturn:@[element]] getDropDownMenuElementsFromHTML:testHTML];

    [self.dropDownMenu parseItemsFromHTML:testHTML];
    CernerOCMockVerify(mockDropDownMenu);

    [mockParser stopMocking];
    [mockDropDownMenu stopMocking];
}

@end
