//
//  HTMLParserTesterTests.m
//  CernerBridgeTests
//
//  Created by Shoemake,Andrew on 9/13/18.
//  Copyright © 2018 DWx CareAware Connect. All rights reserved.
//

#import <XCTest/XCTest.h>

#import "HTMLElement.h"
#import "HTMLParser.h"

@interface HTMLParserTest : XCTestCase

@property (nonatomic, strong) HTMLParser *parser;

@end

@implementation HTMLParserTest

- (void)setUp {
    self.parser = [[HTMLParser alloc] init];
}

- (void)tearDown {
    self.parser = nil;
}

- (NSString *)simpleHTML {
    return @"<html><body>\
            <div id='test'><a>Hello</a></div>\
            <a>Text 2</a>\
            </body></html>";
}

- (NSString *)multiplePropertiesHTML {
    return @"<html><body>\
    <div id='test' source='no_source' extra='7'><a href='test/coo;'>Hello</a></div>\
    <a>Text 2</a>\
    </body></html>";
}

- (NSString *)invalidHTML {
    return @"hello there/a>how are you??";
}

/**
 * Verify the div element is retrieved
 */
- (void)testElementsFromHTML_Simple_FindDiv {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self simpleHTML] withXPath:@"//div"];
    XCTAssertEqual(1, elements.count);
    HTMLElement *element = elements[0];
    XCTAssertEqualObjects(@"test", element.properties[@"id"]);
}

/**
 * Verify the a elements are retrieved
 */
- (void)testElementsFromHTML_Simple_Find_A {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self simpleHTML] withXPath:@"//a"];
    XCTAssertEqual(2, elements.count);
    HTMLElement *element1 = elements[0];
    HTMLElement *element2 = elements[1];
    XCTAssertEqualObjects(@"Hello", element1.text);
    XCTAssertEqualObjects(@"Text 2", element2.text);
}

/**
 * Verify the a element that is a descended of a div element is retrieved
 */
- (void)testElementsFromHTML_Simple_Find_A_InDiv {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self simpleHTML] withXPath:@"//div//a"];
    XCTAssertEqual(1, elements.count);
    HTMLElement *element1 = elements[0];
    XCTAssertEqualObjects(@"Hello", element1.text);
}

/**
 * Verify an empty array is returned if the query is invalid
 */
- (void)testElementsFromHTML_Simple_InvalidQuery {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self simpleHTML] withXPath:@"\a>?"];
    XCTAssertEqual(0, elements.count);
}

/**
 * Verify the div element is returned with all properties
 */
- (void)testElementsFromHTML_MultiProperty {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self multiplePropertiesHTML] withXPath:@"//div"];
    XCTAssertEqual(1, elements.count);
    HTMLElement *element = elements[0];
    XCTAssertEqualObjects(@"test", element.properties[@"id"]);
    XCTAssertEqualObjects(@"no_source", element.properties[@"source"]);
    XCTAssertEqualObjects(@"7", element.properties[@"extra"]);
}

/**
 * Verify an empty array is returned for invalid html
 */
- (void)testElementsFromHTML_InvalidHTML_GoodQuery {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self invalidHTML] withXPath:@"//a"];
    XCTAssertEqual(0, elements.count);
}

/**
 * Verify an empty array is returned for invalid html
 */
- (void)testElementsFromHTML_InvalidHTML_InvalidQuery {
    NSArray<HTMLElement *> *elements = [self.parser elementsFromHTML:[self invalidHTML] withXPath:@"\a>?"];
    XCTAssertEqual(0, elements.count);
}

@end
