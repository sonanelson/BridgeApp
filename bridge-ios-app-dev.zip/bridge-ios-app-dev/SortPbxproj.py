#!/usr/bin/python
import sys
import re
import string
import os


groupAndFolderArray = []

def main():
  rootdir = '.'
  directories = [name for name in os.listdir(rootdir) if os.path.isdir(os.path.join(rootdir,name))]
  xcodeproj = None
  for directory in directories:
    isxcodeproj = re.search(r'\w*\.xcodeproj',directory)
    if(isxcodeproj):
      xcodeproj = directory
  
  if not xcodeproj:
    print 'No xcodeproj in current directory'
    return
  
  filename = os.path.join(xcodeproj,'project.pbxproj')
  
  if not filename:
    print 'No project.pbxproj file inside ' +xcodeproj
    return
  
  
  projectfile = open(filename,r'r+U')
  filecontents = projectfile.read()
  
  #figure out everything that is a group
  global groupAndFolderArray 
  uuidsAndTypes = re.findall(r'\n\s+([\dABCDEF]{24})\s+\/\*\s+.+?\*\/ = \{\s*isa = (\w+)\s*;',filecontents)
  for uuidAndType in uuidsAndTypes:
    if uuidAndType[1] == 'PBXGroup':
      groupAndFolderArray.append(uuidAndType[0])
  
  #now find all of the folder references
  for pbxfolder in re.findall(r'\n\s+([\dABCDEF]{24}) \/\*\s+.+?\*\/ = \{\s*isa = PBXFileReference; lastKnownFileType = folder',filecontents):
    groupAndFolderArray.append(pbxfolder)
  
  #sort all the children
  replacecontents = re.subn(r'\n\s+[\dABCDEF]{24}\s+\/\*\s+(\w+)\s*\*\/ = \{\s*isa = \w+;\s*\w*(children = \([\S\s]*?\);)', sortChildGroup, filecontents)
  replacecontents = re.subn(r'\n\s+([\dABCDEF]{24})\s+= \{\s*isa = \w+;\s*\w*(children = \([\S\s]*?\);)', sortChildGroup, replacecontents[0])
  
  #sort all the files
  replacecontents = re.subn(r'\n\s+[\dABCDEF]{24}\s+\/\*\s+(\w+)\s*\*\/ = \{\s*isa = \w+;(?:\s*\w+ = (?:\S+|".*?");)*?\s*(files = \([\S\s]*?\);)', sortChildGroup, replacecontents[0])
  newcontents = replacecontents[0]

  #TODO, sort all the target dependencies also.
  
  #done reading
  projectfile.close()
  
  if newcontents != filecontents:
    #make a backup of existing in the project folder
    backupfile = open('backup.pbxproj', 'w')
    backupfile.write(filecontents)
    backupfile.close()
    
    print "writing file"
    #rewrite the project file.
    testpbxfile = open(filename,'w')
    testpbxfile.write(newcontents)
    testpbxfile.close()
  else:
    print "no changes made"
  
def sortChildGroup(childGroup):
  if(childGroup.group(1) == 'Products'):
    return childGroup.group(0)
    
  children = re.findall(r'\s+[\dABCDEF]{24}\s+\/\*[\s\S]+?\*\/,', childGroup.group(2))

  replaceChildStr = "("
  for child in sorted(children, key=sortFn):
    replaceChildStr += child

  return childGroup.group(0).replace(childGroup.group(2),re.sub(r'\([\s\S]+\*\/\,', replaceChildStr, childGroup.group(2)))
  

def sortFn(item):
  sortTuple = re.search(r'\s+(\S+)\s+\/\*([\s\S]+?)\*\/,', item)

  sortStr = sortTuple.group(2)
  global groupAndFolderArray
  
  #if the object is not a group or folder...
  if not sortTuple.group(1) in groupAndFolderArray:
    sortStr = "~"+sortStr
    #if it's an xcodeproj file, sort it lower.
    if re.search(r'\.xcodeproj',sortStr):
      sortStr = "~"+sortStr
        
  #do case insensitive sort
  return sortStr.lower()
  
if __name__ == '__main__':
  main()
  